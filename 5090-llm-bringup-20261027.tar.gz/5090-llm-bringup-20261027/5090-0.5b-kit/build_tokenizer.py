#!/usr/bin/env python3
"""
训练一个 64k 词表的 ByteLevel BPE tokenizer（从零预训练用）。

用法:
    python build_tokenizer.py --input data/sample_10gb.jsonl --vocab-size 64000 -o tokenizer.json

输入是 JSONL，每行 {"text": "..."}，字段名可用 --text-key 改。
样本 10–20 GB 足够，不需要全量语料。
"""
import argparse
import json
import sys

from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers

SPECIAL_TOKENS = [
    "<|endoftext|>",   # 文档分隔 / padding 可用
    "<|im_start|>",
    "<|im_end|>",
    "<|pad|>",
]


def iter_texts(path: str, text_key: str, limit: int | None):
    with open(path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if limit is not None and i >= limit:
                break
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            text = obj.get(text_key)
            if isinstance(text, str) and text:
                yield text


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="jsonl 文件（可多个，逗号分隔）")
    ap.add_argument("--text-key", default="text")
    ap.add_argument("--vocab-size", type=int, default=64000)
    ap.add_argument("--min-frequency", type=int, default=2)
    ap.add_argument("--output", "-o", default="tokenizer.json")
    ap.add_argument("--limit", type=int, default=None, help="只读前 N 行，调试用")
    args = ap.parse_args()

    paths = [p.strip() for p in args.input.split(",") if p.strip()]
    if not paths:
        print("没有输入文件", file=sys.stderr)
        return 1

    tok = Tokenizer(models.BPE(unk_token=None, byte_fallback=False, dropout=None))

    # ByteLevel：任何 Unicode 都不会 OOV
    # Digits：把数字按位切分（Llama 3 的做法），对算术能力有实测收益
    tok.pre_tokenizer = pre_tokenizers.Sequence(
        [
            pre_tokenizers.ByteLevel(add_prefix_space=False, use_regex=True),
            pre_tokenizers.Digits(individual_digits=True),
        ]
    )
    tok.decoder = decoders.ByteLevel()

    trainer = trainers.BpeTrainer(
        vocab_size=args.vocab_size,
        min_frequency=args.min_frequency,
        special_tokens=SPECIAL_TOKENS,
        initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),
        show_progress=True,
    )

    def corpus():
        for p in paths:
            print(f"  读取 {p} ...", file=sys.stderr)
            yield from iter_texts(p, args.text_key, args.limit)

    print(f"开始训练 BPE，目标词表 {args.vocab_size}", file=sys.stderr)
    tok.train_from_iterator(corpus(), trainer=trainer)

    tok.save(args.output)

    # 自检：往返一致性
    probe = "星露谷的秋天，Abigail 说：我们去看海吧！cost=1999 元。"
    ids = tok.encode(probe).ids
    back = tok.decode(ids)
    print(f"\n自检: {len(ids)} tokens")
    print(f"  原始: {probe}")
    print(f"  还原: {back}")
    print(f"  {'✓' if back.replace(' ', '') == probe.replace(' ', '') else '✗ 往返不一致，检查 decoder'}")

    print(f"\n词表 {tok.get_vocab_size()} 已保存到 {args.output}")
    print("下一步: python pack_corpus.py --input data/clean/*.jsonl "
          f"--tokenizer {args.output} -o data/packed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
