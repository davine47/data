# 5090-0.5b-kit

可执行代码。两份文档：
- [跑通流程施工计划](../5090-0.5B-跑通流程-施工计划.md) ← **当前阶段**
- [训练全流程（质量阶段）](../RTX5090-0.5B-LLM训练全流程.md) ← 参考

```
5090-0.5b-kit/
├── bringup.py            ★ 一条命令跑通全流程 + 出 PASS 报告
├── profiler.py           ★ 性能画像：时间分解 / MFU / 算子热点
├── env_check.py          环境自检（sm_120 / bf16 / SDPA / 显存）
├── build_tokenizer.py    训练 ByteLevel BPE
├── pack_corpus.py        jsonl → uint16 .bin + meta.json
├── pretrain.py           单卡 BF16 预训练（分块 loss、断点续训、compile）
├── requirements.txt
└── configs/
    ├── toy.yaml              玩具档 5.5M（验证管线，7 秒）
    ├── 0.5b.yaml             从零预训练 494M
    ├── dapt_qwen3_0.6b.yaml  继续预训练（LLaMA-Factory）
    ├── sft_qwen3_0.6b.yaml   SFT（LLaMA-Factory）
    └── dpo_qwen3_0.6b.yaml   DPO / ORPO（LLaMA-Factory）
```

## 最快跑通（推荐从这里开始）

```bash
python bringup.py --tier toy --device cpu     # 约 7 秒，6 个阶段全绿
python bringup.py --tier full --device cuda   # 约 1.5–2 小时，5090
cat runs/bringup_*/report.md
```

`bringup.py` 会依次跑：环境 → 合成语料 → 分词 → 打包 → 训练 → 存档重载校验 → 生成 → 困惑度，
最后输出 `report.json` / `report.md` 和一个**完整可复现的 run 目录**。

## 性能画像

```bash
python profiler.py --config runs/bringup_full_xxx/config.yaml --device cuda --steps 20 --trace
```

给出：每步时间分解（data/fwd/bwd/optim）、MFU、显存峰值、算子级热点表、chrome trace。


## 快速开始

### 0. 装环境（一次）

```bash
conda create -n llm5090 python=3.12 -y && conda activate llm5090

# 关键：必须 cu128/cu130 的官方 wheel
pip install torch --index-url https://download.pytorch.org/whl/cu130
pip install -r requirements.txt

python env_check.py     # 必须全绿
```

### 1. 从零训练（路线 A）

```bash
# 语料 -> tokenizer（10–20GB 样本足够）
python build_tokenizer.py --input data/sample.jsonl --vocab-size 64000 -o tokenizer.json

# 语料 -> 二进制分片（训练时 GPU 不用等 CPU）
python pack_corpus.py --input data/clean/*.jsonl --tokenizer tokenizer.json -o data/packed

# 冒烟 200 步：确认 loss 从 ~11 开始掉
python pretrain.py --config configs/0.5b.yaml --out runs/v0 --max-steps 200 --no-compile

# 正式训练 10B tokens（约 6–8 天）
nohup python pretrain.py --config configs/0.5b.yaml --out runs/v0 > train.log 2>&1 &

# 断了就续
python pretrain.py --config configs/0.5b.yaml --out runs/v0 --resume auto
```

> 先把 `configs/0.5b.yaml` 里的 `data:` 指向你的 `data/packed/meta.json`。

### 2. 继续预训练 + 后训练（路线 B / C，推荐）

```bash
# DAPT：在你的领域语料上再训 1–3B tokens
llamafactory-cli train configs/dapt_qwen3_0.6b.yaml

# SFT
llamafactory-cli train configs/sft_qwen3_0.6b.yaml

# DPO（可选）
llamafactory-cli train configs/dpo_qwen3_0.6b.yaml
```

### 3. 评测与部署

```bash
lm_eval --model hf --model_args pretrained=runs/sft-qwen3-0.6b,dtype=bfloat16 \
        --tasks mmlu,ceval-valid --batch_size 8

vllm serve runs/sft-qwen3-0.6b --dtype bfloat16 --port 8000
```

## 两个脚本的分工

| | 用谁 | 为什么 |
|---|---|---|
| 从零预训练 | `pretrain.py` | 自己定义架构，完全可控 |
| DAPT / SFT / DPO | LLaMA-Factory | Qwen3 有 QK-Norm，权重不能灌进 `pretrain.py` 的模型；框架已处理好架构、packing、chunked loss |

**不要**试图把 Qwen3 权重加载进 `pretrain.py`——架构不同（QK-Norm），会静默训出一个废模型。

## 已知限制

- **已在 CPU 上端到端验证**（tiny 配置 + 合成语料）：tokenizer 训练、语料打包、预训练前向/反向、存档、`--resume auto` 续训、分块 loss 与整块数值一致（误差 5e-7）。
- **未在 5090 真机上跑过**。首次运行请务必 `--max-steps 200 --no-compile` 冒烟。
- `pretrain.py` 只实现了 Llama 基础架构，不含 QK-Norm / MoE / 长上下文外推。
- `pack_corpus.py` 是单进程的；100GB 级语料建议按文件并行跑多个进程，再合并 `meta.json`。
- LLaMA-Factory 的 `dataset_info.json` 需要你自己注册数据集名。
