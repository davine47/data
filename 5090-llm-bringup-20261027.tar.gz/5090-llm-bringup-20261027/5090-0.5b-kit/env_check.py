#!/usr/bin/env python3
"""
环境自检：确认 RTX 5090 (sm_120) 的软件栈可用。

用法:
    python env_check.py
退出码 0 = 可以开始训练；非 0 = 有问题，按提示修。
"""
import sys


def fail(msg: str) -> None:
    print(f"  ✗ {msg}")


def ok(msg: str) -> None:
    print(f"  ✓ {msg}")


def main() -> int:
    problems = 0
    print("=" * 62)
    print("RTX 5090 / 0.5B 训练环境自检")
    print("=" * 62)

    # ---- Python ----
    print(f"\n[Python] {sys.version.split()[0]}")
    if sys.version_info < (3, 10):
        fail("建议 Python 3.10+")
        problems += 1

    # ---- torch ----
    try:
        import torch
    except Exception as e:  # noqa: BLE001
        fail(f"无法 import torch: {e}")
        print("\n    修复: pip install torch --index-url https://download.pytorch.org/whl/cu130")
        return 1

    print(f"[torch] {torch.__version__}")
    print(f"[CUDA runtime] {torch.version.cuda}")

    if not torch.cuda.is_available():
        fail("CUDA 不可用：驱动没装好，或 torch 是 CPU 版")
        return 1

    name = torch.cuda.get_device_name(0)
    cap = torch.cuda.get_device_capability(0)
    vram = torch.cuda.get_device_properties(0).total_memory / 1024**3
    print(f"[GPU] {name}  sm_{cap[0]}{cap[1]}  {vram:.1f} GiB")

    # ---- 关键检查 1: sm_120 必须有 kernel ----
    if cap < (12, 0):
        fail(f"算力 {cap} 低于 sm_120，这不是 5090（或是老驱动只暴露了兼容 arch）")
        problems += 1
    else:
        try:
            x = torch.randn(512, 512, device="cuda", dtype=torch.bfloat16)
            _ = x @ x.T
            ok("BF16 矩阵乘可执行（sm_120 kernel 存在）")
        except Exception as e:  # noqa: BLE001
            fail(f"BF16 矩阵乘失败（典型的 torch 版本不匹配）: {e}")
            print("    修复: 重装 cu128/cu130 的 torch wheel，不要用 conda 的 pytorch")
            problems += 1

    # ---- 关键检查 2: bf16 支持 ----
    if torch.cuda.is_bf16_supported():
        ok("硬件支持 BF16")
    else:
        fail("不支持 BF16，训练会很麻烦")
        problems += 1

    # ---- 关键检查 3: SDPA（不装 flash-attn 也能跑得快）----
    try:
        import torch.nn.functional as F

        q = torch.randn(2, 8, 1024, 64, device="cuda", dtype=torch.bfloat16)
        _ = F.scaled_dot_product_attention(q, q, q, is_causal=True)
        ok("scaled_dot_product_attention 可用（推荐主力，无需 flash-attn）")
    except Exception as e:  # noqa: BLE001
        fail(f"SDPA 不可用: {e}")
        problems += 1

    # ---- 可选组件 ----
    print("\n[可选组件]")
    for mod, hint in [
        ("yaml", "pyyaml"),
        ("numpy", "numpy"),
        ("tokenizers", "tokenizers"),
        ("datasets", "datasets"),
        ("transformers", "transformers"),
        ("peft", "peft"),
        ("trl", "trl"),
    ]:
        try:
            m = __import__(mod)
            ok(f"{mod} {getattr(m, '__version__', '')}")
        except Exception:  # noqa: BLE001
            fail(f"{mod} 未安装 → pip install {hint}")
            problems += 1

    # ---- 显存够不够（0.5B 全参）----
    print("\n[容量评估]")
    need = 10.0  # 0.5B bf16 + AdamW fp32，含激活，保守值
    if vram >= need:
        ok(f"{vram:.0f} GiB ≥ 需求约 {need:.0f} GiB，0.5B 全参训练无压力")
        if vram >= 24:
            ok("可关梯度检查点 / 开 8k 上下文")
    else:
        fail(f"显存不足：需要约 {need:.0f} GiB，只有 {vram:.0f} GiB")
        problems += 1

    print("\n" + "=" * 62)
    if problems == 0:
        print("结论: 环境 OK，可以开始。")
    else:
        print(f"结论: 有 {problems} 个问题，先修再训。")
    print("=" * 62)
    return 0 if problems == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
