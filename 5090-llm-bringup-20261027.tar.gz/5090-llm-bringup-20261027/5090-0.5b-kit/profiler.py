#!/usr/bin/env python3
"""
性能画像：一次运行给出「每步时间分解 + MFU + 显存峰值 + 算子级热点」。

架构师关心的不是 loss，是这四件事：
  1. 一个 step 的时间花在哪（数据 / 前向 / 反向 / 优化器）
  2. 算力利用率 MFU 是多少
  3. 显存峰值与理论值的差
  4. 哪些 kernel 吃掉了时间

用法:
    python profiler.py --config runs/bringup_xxx/config.yaml --device cuda --steps 20
    python profiler.py --config ... --trace          # 额外导出 chrome trace
    python profiler.py --config ... --peak 209.5     # 手动指定峰值 TFLOPS

产物:
    <config 所在目录>/profile.json
    trace.json（--trace 时）
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

import torch
import yaml
from torch.utils.data import DataLoader

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import pretrain as P  # noqa: E402

# BF16 稠密算力（TFLOPS），用于算 MFU
PEAK_TFLOPS = {
    "5090": 209.5, "5080": 112.0, "4090": 165.2, "4080": 97.5,
    "H100": 989.0, "A100": 312.0, "L40S": 362.0,
}


def guess_peak(name: str) -> float | None:
    for k, v in PEAK_TFLOPS.items():
        if k.lower() in name.lower():
            return v
    return None


def sync(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--steps", type=int, default=20, help="计时用的步数")
    ap.add_argument("--warmup", type=int, default=3, help="预热步数，不计入统计")
    ap.add_argument("--peak", type=float, default=None, help="峰值 TFLOPS")
    ap.add_argument("--trace", action="store_true", help="导出 chrome trace")
    ap.add_argument("--top", type=int, default=20, help="打印前 N 个热点算子")
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    device = torch.device(args.device)

    model = P.LlamaMini(cfg).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    tokens_per_step = cfg["micro_batch_size"] * cfg["grad_accum"] * cfg["seq_len"]

    ds = P.PackedDataset(cfg["data"], cfg["seq_len"], seed=0)
    loader = DataLoader(ds, batch_size=cfg["micro_batch_size"],
                        num_workers=cfg.get("num_workers", 0),
                        pin_memory=(device.type == "cuda"), drop_last=True)
    it = P.infinite(loader)

    opt = torch.optim.AdamW(model.parameters(), lr=cfg["lr"],
                            betas=(cfg["beta1"], cfg["beta2"]),
                            fused=(device.type == "cuda"))
    grad_ckpt = cfg.get("grad_checkpoint", False)
    flops_per_token = (8 if grad_ckpt else 6) * n_params
    peak = args.peak or (guess_peak(torch.cuda.get_device_name(0))
                         if device.type == "cuda" else None)

    timings = {"data": [], "forward": [], "backward": [], "optim": []}
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()

    for step in range(args.warmup + args.steps):
        record = step >= args.warmup

        sync(device)
        t0 = time.perf_counter()
        opt.zero_grad(set_to_none=True)
        for _ in range(cfg["grad_accum"]):
            x, y = next(it)
            x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
            t1 = time.perf_counter()
            sync(device)
            with P.amp_ctx(device):
                loss = model(x, labels=y, grad_ckpt=grad_ckpt)
            sync(device)
            t2 = time.perf_counter()
            (loss / cfg["grad_accum"]).backward()
            sync(device)
            t3 = time.perf_counter()
            if record:
                timings["data"].append(t1 - t0)
                timings["forward"].append(t2 - t1)
                timings["backward"].append(t3 - t2)
            t0 = time.perf_counter()
        torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["grad_clip"])
        opt.step()
        sync(device)
        t4 = time.perf_counter()
        if record:
            timings["optim"].append(t4 - t0)

    mean = {k: (sum(v) / len(v) * 1000 if v else 0.0) for k, v in timings.items()}
    total_ms = sum(mean.values())
    tps = tokens_per_step / (total_ms / 1000) if total_ms > 0 else 0
    mfu = (flops_per_token * tps) / (peak * 1e12) if peak else None

    print("\n" + "=" * 72)
    print(f"  性能画像  {torch.cuda.get_device_name(0) if device.type == 'cuda' else args.device}")
    print("=" * 72)
    print(f"  参数量          {n_params/1e6:.1f} M")
    print(f"  每步 tokens     {tokens_per_step:,}  (micro {cfg['micro_batch_size']} × "
          f"accum {cfg['grad_accum']} × seq {cfg['seq_len']})")
    print(f"  梯度检查点      {'开（按 8N 计 FLOPs）' if grad_ckpt else '关（按 6N 计）'}")
    print(f"  吞吐            {tps/1000:.1f} k tokens/s")
    if mfu is not None:
        print(f"  MFU             {mfu*100:.1f} %   (峰值 {peak:.0f} TFLOPS)")
    else:
        print("  MFU             未知（非 CUDA 设备，用 --peak 指定）")
    if device.type == "cuda":
        alloc = torch.cuda.max_memory_allocated() / 1024**3
        reserved = torch.cuda.max_memory_reserved() / 1024**3
        print(f"  显存峰值        {alloc:.2f} GiB 已分配 / {reserved:.2f} GiB 保留")

    print("\n  每步时间分解（accum 内均值 × accum）")
    print(f"  {'阶段':<10}{'毫秒':>10}{'占比':>10}{'说明':>28}")
    notes = {
        "data": "应接近 0；高 = 数据管线瓶颈",
        "forward": "≈ backward 的一半",
        "backward": "通常是前向的 2 倍",
        "optim": "AdamW，GPU 上一般 < 10%",
    }
    for k in ["data", "forward", "backward", "optim"]:
        ms = mean[k]
        pct = ms / total_ms * 100 if total_ms else 0
        print(f"  {k:<10}{ms:>10.2f}{pct:>9.1f}%{notes[k]:>28}")
    print(f"  {'合计':<10}{total_ms:>10.2f}{100.0:>9.1f}%")

    # ---- 算子级热点 ----
    ops_table = ""
    if args.trace or args.steps > 0:
        acts = [torch.profiler.ProfilerActivity.CPU]
        if device.type == "cuda":
            acts.append(torch.profiler.ProfilerActivity.CUDA)
        try:
            with torch.profiler.profile(
                activities=acts,
                record_shapes=True,
                profile_memory=False,
            ) as prof:
                for _ in range(3):
                    opt.zero_grad(set_to_none=True)
                    x, y = next(it)
                    x, y = x.to(device), y.to(device)
                    with P.amp_ctx(device):
                        loss = model(x, labels=y, grad_ckpt=grad_ckpt)
                    loss.backward()
                    opt.step()
            sort_by = "self_cuda_time_total" if device.type == "cuda" else "self_cpu_time_total"
            ops_table = prof.key_averages().table(sort_by=sort_by, row_limit=args.top)
            print("\n  算子级热点（按 self time 排序）")
            print(ops_table)
            if args.trace:
                path = os.path.join(os.path.dirname(os.path.abspath(args.config)), "trace.json")
                prof.export_chrome_trace(path)
                print(f"  chrome trace → {path}")
        except Exception as e:  # noqa: BLE001
            print(f"\n  ⚠ 算子级 profiling 失败（不影响上面的数据）: {e}")

    out = {
        "device": str(device),
        "params_m": round(n_params / 1e6, 2),
        "tokens_per_step": tokens_per_step,
        "tok_per_s": round(tps, 1),
        "mfu": round(mfu, 4) if mfu else None,
        "peak_tflops": peak,
        "phase_ms": {k: round(v, 3) for k, v in mean.items()},
        "total_ms": round(total_ms, 3),
        "grad_checkpoint": grad_ckpt,
        "ops_table": ops_table,
    }
    if device.type == "cuda":
        out["peak_alloc_gib"] = round(torch.cuda.max_memory_allocated() / 1024**3, 2)

    path = os.path.join(os.path.dirname(os.path.abspath(args.config)), "profile.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"\n  结果 → {path}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
