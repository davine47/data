#!/usr/bin/env python3
"""
单卡 RTX 5090 从零预训练 0.5B Llama 风格模型（最小可用实现，不依赖训练框架）。

设计要点:
  * BF16 autocast + FP32 优化器状态
  * 分块交叉熵：避免 (B,T,V) 的 logits 撑爆显存（64k 词表 × 4096 × 8 就是 4GB+）
  * memmap + uint16 读取预打包语料，GPU 不等 CPU
  * 断点续训（含优化器状态）、梯度累积、余弦退火、梯度裁剪
  * 可选 torch.compile / 梯度检查点 / wandb

用法:
    python pretrain.py --config configs/0.5b.yaml --out runs/v0 --max-steps 200   # 冒烟
    python pretrain.py --config configs/0.5b.yaml --out runs/v0                  # 正式
    python pretrain.py --config configs/0.5b.yaml --out runs/v0 --resume auto    # 续训
"""
from __future__ import annotations

import argparse
import contextlib
import glob
import json
import math
import os
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import yaml
from torch.utils.data import DataLoader, Dataset

torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cudnn.allow_tf32 = True


# --------------------------------------------------------------------------- #
# 模型
# --------------------------------------------------------------------------- #
class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-5):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # 用 fp32 算归一化，避免 bf16 下方差精度不足
        dtype = x.dtype
        xf = x.float()
        xf = xf * torch.rsqrt(xf.pow(2).mean(-1, keepdim=True) + self.eps)
        return xf.to(dtype) * self.weight


def build_rope(seq_len: int, head_dim: int, theta: float, device: torch.device):
    inv_freq = 1.0 / (theta ** (torch.arange(0, head_dim, 2, device=device).float() / head_dim))
    t = torch.arange(seq_len, device=device).float()
    freqs = torch.outer(t, inv_freq)          # (T, head_dim/2)
    return torch.cos(freqs), torch.sin(freqs)


def apply_rope(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
    """x: (B, H, T, D)。half-split 旋转，与 HF Llama 的 rotate_half 一致。"""
    cos = cos[None, None, :, :].to(x.dtype)
    sin = sin[None, None, :, :].to(x.dtype)
    x1, x2 = x.chunk(2, dim=-1)
    return torch.cat([x1 * cos - x2 * sin, x2 * cos + x1 * sin], dim=-1)


class Attention(nn.Module):
    def __init__(self, cfg: dict):
        super().__init__()
        self.n_heads = cfg["n_heads"]
        self.n_kv_heads = cfg["n_kv_heads"]
        self.head_dim = cfg["d_model"] // self.n_heads
        d = cfg["d_model"]
        self.q_proj = nn.Linear(d, self.n_heads * self.head_dim, bias=False)
        self.k_proj = nn.Linear(d, self.n_kv_heads * self.head_dim, bias=False)
        self.v_proj = nn.Linear(d, self.n_kv_heads * self.head_dim, bias=False)
        self.o_proj = nn.Linear(self.n_heads * self.head_dim, d, bias=False)

    def forward(self, x, cos, sin):
        B, T, _ = x.shape
        q = self.q_proj(x).view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(B, T, self.n_kv_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(B, T, self.n_kv_heads, self.head_dim).transpose(1, 2)

        q = apply_rope(q, cos, sin)
        k = apply_rope(k, cos, sin)

        if self.n_kv_heads != self.n_heads:
            r = self.n_heads // self.n_kv_heads
            k = k.repeat_interleave(r, dim=1)
            v = v.repeat_interleave(r, dim=1)

        # 5090 上走 cuDNN backend，速度已接近手写 flash-attn
        y = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        y = y.transpose(1, 2).reshape(B, T, -1)
        return self.o_proj(y)


class SwiGLU(nn.Module):
    def __init__(self, d: int, h: int):
        super().__init__()
        self.gate_proj = nn.Linear(d, h, bias=False)
        self.up_proj = nn.Linear(d, h, bias=False)
        self.down_proj = nn.Linear(h, d, bias=False)

    def forward(self, x):
        return self.down_proj(F.silu(self.gate_proj(x)) * self.up_proj(x))


class Block(nn.Module):
    def __init__(self, cfg: dict):
        super().__init__()
        self.norm1 = RMSNorm(cfg["d_model"], cfg["norm_eps"])
        self.attn = Attention(cfg)
        self.norm2 = RMSNorm(cfg["d_model"], cfg["norm_eps"])
        self.mlp = SwiGLU(cfg["d_model"], cfg["ffn_hidden"])

    def forward(self, x, cos, sin):
        x = x + self.attn(self.norm1(x), cos, sin)
        x = x + self.mlp(self.norm2(x))
        return x


class LlamaMini(nn.Module):
    def __init__(self, cfg: dict):
        super().__init__()
        self.cfg = cfg
        self.rope_cache: dict = {}
        self.tok_emb = nn.Embedding(cfg["vocab_size"], cfg["d_model"])
        self.blocks = nn.ModuleList([Block(cfg) for _ in range(cfg["n_layers"])])
        self.norm = RMSNorm(cfg["d_model"], cfg["norm_eps"])
        self.lm_head = nn.Linear(cfg["d_model"], cfg["vocab_size"], bias=False)
        if cfg.get("tie_embeddings", True):
            self.lm_head.weight = self.tok_emb.weight

        self.apply(self._init_weights)
        # 残差投影缩放初始化：深层模型能训起来的关键之一
        std = 0.02 / math.sqrt(2 * cfg["n_layers"])
        for name, p in self.named_parameters():
            if name.endswith("o_proj.weight") or name.endswith("down_proj.weight"):
                nn.init.normal_(p, mean=0.0, std=std)

    @staticmethod
    def _init_weights(m):
        if isinstance(m, nn.Linear):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Embedding):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)

    def _rope(self, T: int, device: torch.device):
        key = (str(device), T)
        if key not in self.rope_cache:
            hd = self.cfg["d_model"] // self.cfg["n_heads"]
            self.rope_cache[key] = build_rope(T, hd, self.cfg["rope_theta"], device)
        return self.rope_cache[key]

    def forward(self, idx, labels=None, grad_ckpt: bool = False, loss_chunk: int = 1024):
        B, T = idx.shape
        cos, sin = self._rope(T, idx.device)

        h = self.tok_emb(idx)
        for blk in self.blocks:
            if grad_ckpt and self.training:
                h = torch.utils.checkpoint.checkpoint(blk, h, cos, sin, use_reentrant=False)
            else:
                h = blk(h, cos, sin)
        h = self.norm(h)

        if labels is None:
            return self.lm_head(h)

        # 分块算 loss：logits 只保留一个 chunk，显存与 T 解耦
        ntok = int((labels != -100).sum().item())
        total = h.new_zeros(())
        for s in range(0, T, loss_chunk):
            e = min(s + loss_chunk, T)
            logits = self.lm_head(h[:, s:e])
            total = total + F.cross_entropy(
                logits.reshape(-1, logits.size(-1)),
                labels[:, s:e].reshape(-1),
                ignore_index=-100,
                reduction="sum",
            )
        return total / max(ntok, 1)


# --------------------------------------------------------------------------- #
# 数据
# --------------------------------------------------------------------------- #
class PackedDataset(Dataset):
    """从 pack_corpus.py 产出的 memmap 分片里随机取定长窗口。"""

    def __init__(self, meta_path: str, seq_len: int, seed: int = 0):
        with open(meta_path, "r", encoding="utf-8") as f:
            meta = json.load(f)
        self.meta = meta
        root = os.path.dirname(os.path.abspath(meta_path))
        dt = np.uint16 if meta["dtype"] == "uint16" else np.uint32
        self.seq_len = seq_len
        self.arrays = [np.memmap(os.path.join(root, f), dtype=dt, mode="r") for f in meta["files"]]
        self.lens = np.array([len(a) for a in self.arrays], dtype=np.int64)
        self.cum = np.concatenate([[0], np.cumsum(self.lens)])
        self.total = int(self.lens.sum())
        self.n_samples = max(1, self.total // seq_len)
        self.rng = np.random.default_rng(seed)

    def __len__(self):
        return self.n_samples

    def __getitem__(self, _idx):
        pos = int(self.rng.integers(0, max(1, self.total - self.seq_len - 2)))
        s = int(np.searchsorted(self.cum, pos, side="right") - 1)
        off = pos - int(self.cum[s])
        arr = self.arrays[s]
        if off + self.seq_len + 1 > len(arr):
            off = max(0, len(arr) - self.seq_len - 1)

        chunk = np.asarray(arr[off: off + self.seq_len + 1], dtype=np.int64)
        valid = len(chunk) - 1
        if len(chunk) < self.seq_len + 1:            # 分片过短时的兜底
            chunk = np.pad(chunk, (0, self.seq_len + 1 - len(chunk)))

        x = torch.from_numpy(chunk[:-1])
        y = torch.from_numpy(chunk[1:].copy())
        if valid < self.seq_len:
            y[valid:] = -100
        return x, y


def infinite(loader):
    while True:
        for batch in loader:
            yield batch


# --------------------------------------------------------------------------- #
# 训练
# --------------------------------------------------------------------------- #
def lr_at(step: int, base_lr: float, warmup: int, total: int, min_ratio: float) -> float:
    if step < warmup:
        return base_lr * (step + 1) / max(1, warmup)
    progress = (step - warmup) / max(1, total - warmup)
    progress = min(1.0, progress)
    return base_lr * (min_ratio + (1 - min_ratio) * 0.5 * (1 + math.cos(math.pi * progress)))


def save_ckpt(out_dir: str, model, opt, step: int, cfg: dict, keep: int = 2) -> None:
    path = os.path.join(out_dir, f"step_{step:07d}.pt")
    torch.save(
        {
            "model": model.state_dict(),
            "optim": opt.state_dict(),
            "step": step,
            "cfg": cfg,
        },
        path,
    )
    # 额外存一份 bf16 纯权重，便于直接拿去做 SFT / 推理
    sd = {k: v.to(torch.bfloat16) for k, v in model.state_dict().items()}
    torch.save({"model": sd, "cfg": cfg, "step": step},
               os.path.join(out_dir, "model_bf16.pt"))

    ckpts = sorted(glob.glob(os.path.join(out_dir, "step_*.pt")))
    for old in ckpts[:-keep]:
        os.remove(old)


def find_latest(out_dir: str) -> str | None:
    ckpts = sorted(glob.glob(os.path.join(out_dir, "step_*.pt")))
    return ckpts[-1] if ckpts else None


def amp_ctx(device: torch.device):
    """CUDA 上用 bf16 autocast；CPU/MPS 只用于调试，保持 fp32 避免精度差异。"""
    if device.type == "cuda":
        return torch.autocast("cuda", dtype=torch.bfloat16)
    return contextlib.nullcontext()


@torch.no_grad()
def preview(model, eos_id: int, device: torch.device, n_new: int = 32) -> str:
    """训练中途的空洞自检：给一个 token 让它续写，看是不是从乱码变成词。"""
    model.eval()
    ids = torch.tensor([[eos_id]], device=device)
    for _ in range(n_new):
        with amp_ctx(device):
            logits = model(ids)[:, -1, :].float()
        probs = torch.softmax(logits / 0.8, dim=-1)
        nxt = torch.multinomial(probs, 1)
        ids = torch.cat([ids, nxt], dim=1)
    model.train()
    return f"[{ids.shape[1]} tokens] " + str(ids[0, 1:].tolist())


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--max-steps", type=int, default=None, help="覆盖总步数，冒烟用")
    ap.add_argument("--resume", default=None, help="auto 或具体 .pt 路径")
    ap.add_argument("--no-compile", action="store_true")
    ap.add_argument("--device", default="cuda", help="cuda / mps / cpu，调试用")
    ap.add_argument("--seed", type=int, default=1337)
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    os.makedirs(args.out, exist_ok=True)

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    device = torch.device(args.device)

    model = LlamaMini(cfg).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    print(f"参数量: {n_params / 1e6:.1f}M   d_model={cfg['d_model']} L={cfg['n_layers']} "
          f"vocab={cfg['vocab_size']}")

    # decay：只作用于矩阵；norm 与 embedding 不 decay
    decay, no_decay = [], []
    for n, p in model.named_parameters():
        (decay if p.dim() >= 2 and "tok_emb" not in n else no_decay).append(p)
    opt = torch.optim.AdamW(
        [
            {"params": decay, "weight_decay": cfg["weight_decay"]},
            {"params": no_decay, "weight_decay": 0.0},
        ],
        lr=cfg["lr"],
        betas=(cfg["beta1"], cfg["beta2"]),
        eps=1e-8,
        fused=(device.type == "cuda"),
    )

    micro = cfg["micro_batch_size"]
    accum = cfg["grad_accum"]
    seq_len = cfg["seq_len"]
    tokens_per_step = micro * accum * seq_len
    total_steps = cfg["total_tokens"] // tokens_per_step
    if args.max_steps is not None:
        total_steps = args.max_steps
    print(f"每步 {tokens_per_step:,} tokens  总步数 {total_steps:,}  "
          f"≈ {total_steps * tokens_per_step / 1e9:.2f}B tokens")

    ds = PackedDataset(cfg["data"], seq_len, seed=args.seed)
    loader = DataLoader(
        ds,
        batch_size=micro,
        num_workers=cfg.get("num_workers", 4),
        pin_memory=(device.type == "cuda"),
        drop_last=True,
        persistent_workers=cfg.get("num_workers", 4) > 0,
    )
    print(f"语料: {ds.total:,} tokens, {len(ds):,} 个样本窗口")
    batch_iter = infinite(loader)

    start_step = 0
    resume_path = args.resume
    if resume_path == "auto":
        resume_path = find_latest(args.out)
    if resume_path:
        print(f"续训: {resume_path}")
        ck = torch.load(resume_path, map_location="cpu", weights_only=False)
        model.load_state_dict(ck["model"])
        opt.load_state_dict(ck["optim"])
        start_step = int(ck["step"])
        print(f"  从 step {start_step} 继续")

    if not args.no_compile and cfg.get("compile", True):
        print("torch.compile 中（首次编译需 3–8 分钟，别以为卡死）...")
        model = torch.compile(model)

    use_wandb = False
    if cfg.get("wandb", False):
        try:
            import wandb

            wandb.init(project=cfg.get("wandb_project", "5090-0.5b"),
                       config=cfg, resume="allow")
            use_wandb = True
        except Exception as e:  # noqa: BLE001
            print(f"wandb 不可用，改用本地日志: {e}")

    # eos 从 meta.json 推导，避免 config 与 tokenizer 不一致
    eos_id = int(ds.meta.get("eos_id", cfg.get("eos_id", 0)))
    grad_ckpt = cfg.get("grad_checkpoint", True)
    t0 = time.time()
    seen_tokens = start_step * tokens_per_step

    for step in range(start_step, total_steps):
        lr = lr_at(step, cfg["lr"], cfg["warmup_steps"], total_steps, cfg["min_lr_ratio"])
        for g in opt.param_groups:
            g["lr"] = lr

        opt.zero_grad(set_to_none=True)
        loss_acc = 0.0
        for _ in range(accum):
            x, y = next(batch_iter)
            x = x.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)
            with amp_ctx(device):
                loss = model(x, labels=y, grad_ckpt=grad_ckpt)
            (loss / accum).backward()
            loss_acc += loss.item() / accum

        gnorm = torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["grad_clip"])
        opt.step()
        seen_tokens += tokens_per_step

        if step % cfg.get("log_every", 20) == 0:
            dt = time.time() - t0
            tps = seen_tokens / dt if dt > 0 else 0
            mem = (torch.cuda.max_memory_allocated() / 1024**3
                   if device.type == "cuda" else 0.0)
            print(
                f"step {step:6d}/{total_steps} | loss {loss_acc:7.4f} | lr {lr:.2e} | "
                f"|g| {float(gnorm):6.3f} | {tps / 1000:6.1f}k tok/s | {mem:5.1f} GiB",
                flush=True,
            )
            if use_wandb:
                import wandb

                wandb.log({"loss": loss_acc, "lr": lr, "grad_norm": float(gnorm),
                           "tokens": seen_tokens, "tok_per_s": tps}, step=step)

        if cfg.get("sample_every", 0) and step > 0 and step % cfg["sample_every"] == 0:
            print("  样例:", preview(model, eos_id, device), flush=True)

        if (step + 1) % cfg.get("save_every", 1000) == 0 or step + 1 == total_steps:
            save_ckpt(args.out, model, opt, step + 1, cfg)
            print(f"  ✓ 已保存 step {step + 1}", flush=True)

    print(f"\n完成。总耗时 {(time.time() - t0) / 3600:.2f} 小时")
    print(f"权重: {os.path.join(args.out, 'model_bf16.pt')}")
    print("下一步: 用 LLaMA-Factory 做 SFT，见 configs/sft_qwen3_0.6b.yaml")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
