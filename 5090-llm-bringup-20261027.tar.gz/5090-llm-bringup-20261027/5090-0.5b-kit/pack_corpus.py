#!/usr/bin/env python3
"""
语料打包：JSONL -> uint16/uint32 二进制分片 + meta.json，供 pretrain.py 用 memmap 读取。

这是吞吐的关键：训练时在线 tokenize 会让 GPU 等 CPU，利用率掉到 30%。

用法:
    python pack_corpus.py --input data/clean/*.jsonl --tokenizer tokenizer.json -o data/packed

产物:
    data/packed/meta.json
    data/packed/shard_0000.bin ...
"""
import argparse
import glob
import json
import os
import sys

import numpy as np
from tokenizers import Tokenizer
from tqdm import tqdm

# uint16 上限
UINT16_MAX = 65535


def iter_texts(path: str, text_key: str):
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            text = obj.get(text_key)
            if isinstance(text, str) and text:
                yield text


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="glob 或逗号分隔的 jsonl 列表")
    ap.add_argument("--text-key", default="text")
    ap.add_argument("--tokenizer", required=True)
    ap.add_argument("--output", "-o", default="data/packed")
    ap.add_argument("--shard-tokens", type=int, default=200_000_000,
                    help="每个分片的 token 数（默认 2 亿，uint16 下约 400MB）")
    ap.add_argument("--max-docs", type=int, default=None)
    args = ap.parse_args()

    # 解析输入路径
    if "," in args.input:
        files = [p.strip() for p in args.input.split(",") if p.strip()]
    else:
        files = sorted(glob.glob(args.input))
    files = [f for f in files if os.path.isfile(f)]
    if not files:
        print(f"没有匹配到文件: {args.input}", file=sys.stderr)
        return 1

    tok = Tokenizer.from_file(args.tokenizer)
    vocab_size = tok.get_vocab_size()

    eos_id = tok.token_to_id("<|endoftext|>")
    if eos_id is None:
        print("词表里没有 <|endoftext|>，无法分隔文档", file=sys.stderr)
        return 1

    # 词表能否塞进 uint16 决定了磁盘和 IO 带宽
    if vocab_size <= UINT16_MAX:
        dtype_name, np_dtype = "uint16", np.uint16
    else:
        dtype_name, np_dtype = "uint32", np.uint32
        print(f"⚠️  词表 {vocab_size} > 65535，只能用 uint32（磁盘翻倍）", file=sys.stderr)

    os.makedirs(args.output, exist_ok=True)

    buf: list[int] = []
    buf_arr = np.empty(0, dtype=np_dtype)
    shard_idx = 0
    shard_files: list[str] = []
    total_tokens = 0
    docs = 0

    def flush(buf_arr: np.ndarray) -> None:
        nonlocal shard_idx
        name = f"shard_{shard_idx:04d}.bin"
        path = os.path.join(args.output, name)
        buf_arr.tofile(path)
        shard_files.append(name)
        print(f"  写出 {name}: {len(buf_arr):,} tokens", file=sys.stderr)
        shard_idx += 1

    pbar = tqdm(desc="打包", unit=" docs")
    for path in files:
        for text in iter_texts(path, args.text_key):
            if args.max_docs is not None and docs >= args.max_docs:
                break
            ids = tok.encode(text).ids
            if not ids:
                continue
            buf.extend(ids)
            buf.append(eos_id)          # 每篇文档后加 EOS，模型才知道边界
            docs += 1
            total_tokens += len(ids) + 1
            pbar.update(1)

            # 缓冲区够一个分片就落盘
            if len(buf) >= args.shard_tokens:
                flush(np.asarray(buf, dtype=np_dtype))
                buf = []

        if args.max_docs is not None and docs >= args.max_docs:
            break
    pbar.close()

    if buf:
        flush(np.asarray(buf, dtype=np_dtype))

    meta = {
        "vocab_size": vocab_size,
        "dtype": dtype_name,
        "n_tokens": total_tokens,
        "n_docs": docs,
        "eos_id": eos_id,
        "files": shard_files,
        "tokenizer": os.path.basename(args.tokenizer),
    }
    with open(os.path.join(args.output, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    print(f"\n完成: {total_tokens:,} tokens / {docs:,} docs / {len(shard_files)} 分片")
    print(f"meta: {os.path.join(args.output, 'meta.json')}  (dtype={dtype_name})")
    print("\n下一步: python pretrain.py --config configs/0.5b.yaml --max-steps 200")
    print("提示: 训练前把 meta.json 里的路径填进 configs/0.5b.yaml 的 data 字段")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
