#!/usr/bin/env python3
"""
一条命令跑通 0.5B LLM 训练全流程（不追求质量，只验证管线）。

    语料 → 分词 → 打包 → 训练 → 存档 → 重载校验 → 生成 → 困惑度 → 报告

用法:
    # 功能冒烟：5M toy 模型，CPU 也能跑，约 1 分钟
    python bringup.py --tier toy

    # 性能基准：0.5B，5090 上约 1–2 小时
    python bringup.py --tier full --device cuda --tokens 100000000

    # 用你自己的语料
    python bringup.py --corpus data/clean/*.jsonl --tier full

产物:
    runs/bringup_<时间戳>/
      ├── corpus.jsonl         合成/拷贝的语料
      ├── tokenizer.json
      ├── packed/              二进制分片
      ├── ckpt/                检查点
      ├── config.yaml          实际使用的配置（可直接复现）
      └── report.json / report.md
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import random
import re
import subprocess
import sys
import time
from datetime import datetime

import numpy as np
import torch
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import pretrain as P  # noqa: E402


# --------------------------------------------------------------------------- #
# 语料：没有真实语料时，合成一份"结构正确"的假语料
# --------------------------------------------------------------------------- #
SENTENCES = [
    "星露谷的秋天来了，农夫在田里收南瓜，阿比盖尔说她喜欢下雨天。",
    "The valley woke up under a pale sky, and the farmer counted twenty parsnips before noon.",
    "他沿着河边走了很久，直到看见那座旧磨坊，屋顶已经塌了一半。",
    "She sells seeds at the general store; the price changed again this season.",
    "如果你在矿洞深处迷路，记住梯子总是出现在离你最远的那个角落。",
    "The number of harvested crops was 1287 this year, up from 964 last year.",
    "雨停之后，泥土的味道混着松木的香气，小屋的烟囱开始冒烟。",
    "def water_all(farm):\n    for tile in farm.tiles:\n        tile.water()\n",
    "他从来没有想过，一个普通的星期二会改变他接下来十年的生活。",
    "A quiet morning, a warm cup, and a list that nobody will ever finish.",
]


def make_corpus(path: str, target_mb: float, seed: int = 0) -> int:
    """合成语料：句子随机组合，长度可控。返回文档条数。"""
    rng = random.Random(seed)
    target_bytes = int(target_mb * 1024 * 1024)
    written = 0
    docs = 0
    with open(path, "w", encoding="utf-8") as f:
        while written < target_bytes:
            n = rng.randint(2, 8)
            body = "".join(rng.choice(SENTENCES) for _ in range(n))
            line = json.dumps({"text": body}, ensure_ascii=False)
            f.write(line + "\n")
            written += len(line.encode()) + 1
            docs += 1
    return docs


def make_corpus_from_files(pattern: str, out_path: str, max_mb: float) -> int:
    """把用户提供的 jsonl 截断/合并成一份语料。"""
    files = sorted(glob.glob(pattern)) or [pattern]
    written, docs, cap = 0, 0, max_mb * 1024 * 1024
    with open(out_path, "w", encoding="utf-8") as out:
        for fp in files:
            if not os.path.isfile(fp):
                continue
            with open(fp, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    if written >= cap:
                        return docs
                    out.write(line if line.endswith("\n") else line + "\n")
                    written += len(line.encode()) + 1
                    docs += 1
    return docs


# --------------------------------------------------------------------------- #
# 工具
# --------------------------------------------------------------------------- #
def run(cmd: list[str], log: str) -> str:
    t0 = time.time()
    print(f"      $ {' '.join(cmd)}")
    p = subprocess.run(cmd, cwd=HERE, capture_output=True, text=True)
    out = (p.stdout or "") + (p.stderr or "")
    with open(log, "w", encoding="utf-8") as f:
        f.write(out)
    if p.returncode != 0:
        print(out[-3000:])
        raise SystemExit(f"命令失败（退出码 {p.returncode}）: {' '.join(cmd)}")
    print(f"      完成，用时 {time.time() - t0:.1f}s")
    return out


def human(n: float) -> str:
    for unit in ["", "K", "M", "B"]:
        if abs(n) < 1000:
            return f"{n:.1f}{unit}"
        n /= 1000
    return f"{n:.1f}T"


def count_params(cfg: dict) -> int:
    m = P.LlamaMini(cfg)
    n = sum(p.numel() for p in m.parameters())
    del m
    return n


# --------------------------------------------------------------------------- #
# 各阶段
# --------------------------------------------------------------------------- #
def stage_env(device_name: str) -> dict:
    info = {
        "torch": torch.__version__,
        "cuda_runtime": torch.version.cuda,
        "python": sys.version.split()[0],
        "platform": sys.platform,
        "device": device_name,
    }
    if device_name == "cuda":
        if not torch.cuda.is_available():
            return {**info, "ok": False, "detail": "CUDA 不可用"}
        cap = torch.cuda.get_device_capability(0)
        info.update(
            {
                "gpu": torch.cuda.get_device_name(0),
                "sm": f"{cap[0]}.{cap[1]}",
                "vram_gib": round(torch.cuda.get_device_properties(0).total_memory / 1024**3, 1),
                "bf16": torch.cuda.is_bf16_supported(),
            }
        )
        info["ok"] = bool(info["bf16"]) and (cap >= (7, 0))
    else:
        info["ok"] = True
    return info


def stage_data(root: str, corpus_glob: str | None, corpus_mb: float, vocab: int,
               pad_vocab: bool = True) -> dict:
    corpus = os.path.join(root, "corpus.jsonl")
    if corpus_glob:
        docs = make_corpus_from_files(corpus_glob, corpus, max_mb=corpus_mb)
    else:
        docs = make_corpus(corpus, corpus_mb)
    size_mb = os.path.getsize(corpus) / 1024**2
    print(f"      语料: {docs:,} 篇 / {size_mb:.1f} MB")

    tok_path = os.path.join(root, "tokenizer.json")
    run(
        [sys.executable, "build_tokenizer.py", "--input", corpus,
         "--vocab-size", str(vocab), "-o", tok_path],
        os.path.join(root, "log_tokenizer.txt"),
    )

    # 合成语料的多样性不足时，BPE 凑不到目标词表；
    # 补 reserved token 让模型参数规模与真实数据时一致（否则 "0.5B" 会缩水成 415M）
    padded = False
    cur_vocab = 0
    if pad_vocab:
        from tokenizers import Tokenizer

        tk = Tokenizer.from_file(tok_path)
        cur_vocab = tk.get_vocab_size()
        if cur_vocab < vocab:
            tk.add_tokens([f"<|reserved_{i}|>" for i in range(vocab - cur_vocab)])
            tk.save(tok_path)
            padded = True
            print(f"      词表补齐: {cur_vocab} -> {tk.get_vocab_size()}（合成语料只撑到 {cur_vocab}）")

    packed = os.path.join(root, "packed")
    run(
        [sys.executable, "pack_corpus.py", "--input", corpus,
         "--tokenizer", tok_path, "-o", packed, "--shard-tokens", "5000000"],
        os.path.join(root, "log_pack.txt"),
    )

    meta = json.load(open(os.path.join(packed, "meta.json"), encoding="utf-8"))
    meta["corpus_docs"] = docs
    meta["corpus_mb"] = round(size_mb, 2)
    meta["vocab_padded"] = padded
    meta["vocab_raw"] = cur_vocab
    # 写回磁盘：后续 stage（生成/困惑度）会重新读 meta.json
    with open(os.path.join(packed, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    return meta


def stage_train(root: str, cfg: dict, steps: int, device: str, compile_: bool) -> dict:
    cfg_path = os.path.join(root, "config.yaml")
    with open(cfg_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(cfg, f, allow_unicode=True)

    ckpt_dir = os.path.join(root, "ckpt")
    cmd = [sys.executable, "pretrain.py", "--config", cfg_path, "--out", ckpt_dir,
           "--max-steps", str(steps), "--device", device]
    if not compile_:
        cmd.append("--no-compile")
    t0 = time.time()
    out = run(cmd, os.path.join(root, "log_train.txt"))
    elapsed = time.time() - t0

    losses = [float(m) for m in re.findall(r"loss\s+([0-9.]+)", out)]
    tps = [float(m) for m in re.findall(r"([0-9.]+)k tok/s", out)]
    return {
        "steps": steps,
        "loss_first": losses[0] if losses else None,
        "loss_last": losses[-1] if losses else None,
        "loss_curve": losses[:50],
        "tok_per_s_k": tps[-1] if tps else None,
        "elapsed_s": round(elapsed, 1),
        "ckpt_dir": ckpt_dir,
    }


def _load_model(p: str, device: str):
    ck = torch.load(p, map_location="cpu", weights_only=False)
    cfg = ck["cfg"]
    m = P.LlamaMini(cfg)
    m.load_state_dict({k: v.float() for k, v in ck["model"].items()})
    return m.to(device).eval(), cfg, ck.get("step")


def stage_ckpt(root: str, device: str) -> dict:
    """存档 → 重载 → 两次前向必须完全一致（确定性 + 权重完整性）。"""
    path = os.path.join(root, "ckpt", "model_bf16.pt")
    m1, cfg, step = _load_model(path, device)
    m2, _, _ = _load_model(path, device)

    torch.manual_seed(0)
    x = torch.randint(0, cfg["vocab_size"], (2, 32), device=device)
    with torch.no_grad(), P.amp_ctx(torch.device(device)):
        a = m1(x).float()
        b = m1(x).float()
        c = m2(x).float()
    return {
        "step": step,
        "same_instance_repeatable": bool(torch.equal(a, b)),
        "reload_identical": bool(torch.allclose(a, c, atol=0, rtol=0)),
        "logits_absmax": round(float(a.abs().max()), 4),
    }


def stage_generate(root: str, device: str, n_new: int = 24) -> dict:
    path = os.path.join(root, "ckpt", "model_bf16.pt")
    m, cfg, _ = _load_model(path, device)
    tok = None
    tok_path = os.path.join(root, "tokenizer.json")
    if os.path.exists(tok_path):
        try:
            from tokenizers import Tokenizer

            tok = Tokenizer.from_file(tok_path)
        except Exception:  # noqa: BLE001
            tok = None

    eos, vocab_raw = 0, cfg["vocab_size"]
    meta_p = os.path.join(root, "packed", "meta.json")
    if os.path.exists(meta_p):
        _meta = json.load(open(meta_p, encoding="utf-8"))
        eos = int(_meta.get("eos_id", 0))
        vocab_raw = int(_meta.get("vocab_raw") or _meta.get("vocab_size", vocab_raw))

    ids = torch.tensor([[eos]], device=device)
    for _ in range(n_new):
        with torch.no_grad(), P.amp_ctx(torch.device(device)):
            logits = m(ids)[:, -1, :].float()
        # 补齐用的 reserved token 从未出现在训练数据里，别让它被采样出来
        if vocab_raw < logits.size(-1):
            logits[:, vocab_raw:] = float("-inf")
        probs = torch.softmax(logits / 0.9, dim=-1)
        ids = torch.cat([ids, torch.multinomial(probs, 1)], dim=1)

    new_ids = ids[0, 1:].tolist()
    text = tok.decode(new_ids) if tok else "(无 tokenizer，仅返回 id)"
    return {"n_new": n_new, "ids": new_ids[:24], "text": text}


def stage_ppl(root: str, device: str, seq_len: int = 128, batches: int = 8) -> dict:
    """在训练数据的一段上算困惑度——只验证"能算"，不验证"好不好"。"""
    path = os.path.join(root, "ckpt", "model_bf16.pt")
    m, cfg, _ = _load_model(path, device)

    meta = json.load(open(os.path.join(root, "packed", "meta.json"), encoding="utf-8"))
    root_packed = os.path.join(root, "packed")
    dt = np.uint16 if meta["dtype"] == "uint16" else np.uint32
    arr = np.memmap(os.path.join(root_packed, meta["files"][-1]), dtype=dt, mode="r")
    need = batches * seq_len + 1
    if len(arr) < need:
        arr = np.memmap(os.path.join(root_packed, meta["files"][0]), dtype=dt, mode="r")

    losses = []
    with torch.no_grad():
        for i in range(batches):
            s = i * seq_len
            if s + seq_len + 1 > len(arr):
                break
            chunk = np.asarray(arr[s: s + seq_len + 1], dtype=np.int64)
            x = torch.from_numpy(chunk[:-1])[None].to(device)
            y = torch.from_numpy(chunk[1:])[None].to(device)
            with P.amp_ctx(torch.device(device)):
                losses.append(float(m(x, labels=y, loss_chunk=64)))
    mean = sum(losses) / max(1, len(losses))
    return {"ppl": round(float(np.exp(mean)), 2), "loss": round(mean, 4),
            "batches": len(losses), "vocab": cfg["vocab_size"]}


# --------------------------------------------------------------------------- #
# 主流程
# --------------------------------------------------------------------------- #
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tier", choices=["toy", "full"], default="toy")
    ap.add_argument("--device", default=None, help="cuda / mps / cpu；默认有卡用卡")
    ap.add_argument("--tokens", type=int, default=None, help="训练 token 数（覆盖 tier 默认）")
    ap.add_argument("--steps", type=int, default=None, help="训练步数（覆盖 tier 默认）")
    ap.add_argument("--corpus", default=None, help="自己的语料（jsonl glob），不传则合成")
    ap.add_argument("--corpus-mb", type=float, default=None)
    ap.add_argument("--compile", action="store_true", help="开 torch.compile（第一次会慢）")
    ap.add_argument("--no-pad-vocab", action="store_true",
                    help="不补齐词表（默认补齐，保证 0.5B 档参数规模不缩水）")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    device = args.device or ("cuda" if torch.cuda.is_available() else "cpu")
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    root = args.out or os.path.join(HERE, "runs", f"bringup_{args.tier}_{ts}")
    os.makedirs(root, exist_ok=True)

    if args.tier == "toy":
        preset = dict(d_model=256, n_layers=6, n_heads=8, n_kv_heads=4, ffn_hidden=704,
                      vocab_size=4096, seq_len=128, micro=4, accum=1,
                      tokens=1_000_000, steps=15, corpus_mb=4.0, workers=0)
    else:
        preset = dict(d_model=1280, n_layers=24, n_heads=20, n_kv_heads=4, ffn_hidden=3456,
                      vocab_size=64000, seq_len=4096, micro=8, accum=16,
                      tokens=100_000_000, steps=200, corpus_mb=120.0, workers=4)

    tokens = args.tokens or preset["tokens"]
    steps = args.steps or preset["steps"]
    corpus_mb = args.corpus_mb or preset["corpus_mb"]

    print(f"\n{'='*70}\n bring-up  tier={args.tier}  device={device}  out={root}\n{'='*70}")

    report: dict = {
        "tier": args.tier, "device": device, "started": ts,
        "root": root, "stages": {}, "ok": True,
    }

    def mark(name: str, data: dict, ok: bool | None = None) -> None:
        report["stages"][name] = data
        good = data.get("ok", True) if ok is None else ok
        report["ok"] = report["ok"] and bool(good)
        icon = "✓" if good else "✗"
        print(f"  [{icon}] {name}: {json.dumps(data, ensure_ascii=False, default=str)[:160]}")

    # ---- 1. 环境 ----
    print("\n[1/6] 环境")
    env = stage_env(device)
    mark("env", env)
    if not env.get("ok"):
        print("\n环境不满足，终止。先跑 python env_check.py 看细节。")
        return 1

    # ---- 2. 数据 ----
    print("\n[2/6] 语料 → 分词 → 打包")
    meta = stage_data(root, args.corpus, corpus_mb, preset["vocab_size"], not args.no_pad_vocab)
    mark("data", {
        "ok": meta["n_tokens"] > 0,
        "docs": meta["corpus_docs"],
        "corpus_mb": meta["corpus_mb"],
        "tokens": meta["n_tokens"],
        "vocab": meta["vocab_size"],
        "vocab_raw": meta.get("vocab_raw", meta["vocab_size"]),
        "vocab_padded": meta.get("vocab_padded", False),
        "dtype": meta["dtype"],
        "shards": len(meta["files"]),
    })
    if meta["n_tokens"] <= 0:
        return 1

    # ---- 3. 训练 ----
    print("\n[3/6] 预训练")
    cfg = {
        "d_model": preset["d_model"], "n_layers": preset["n_layers"],
        "n_heads": preset["n_heads"], "n_kv_heads": preset["n_kv_heads"],
        "ffn_hidden": preset["ffn_hidden"], "vocab_size": meta["vocab_size"],
        "tie_embeddings": True, "norm_eps": 1e-5, "rope_theta": 10000,
        "data": os.path.join(root, "packed", "meta.json"),
        "seq_len": preset["seq_len"],
        "micro_batch_size": preset["micro"], "grad_accum": preset["accum"],
        "total_tokens": tokens, "num_workers": preset["workers"],
        "lr": 6e-4 if args.tier == "toy" else 5e-4,
        "min_lr_ratio": 0.1, "warmup_steps": max(2, steps // 10),
        "weight_decay": 0.1, "beta1": 0.9, "beta2": 0.95, "grad_clip": 1.0,
        "grad_checkpoint": args.tier == "full", "compile": bool(args.compile),
        "log_every": 1, "save_every": steps, "sample_every": 0, "wandb": False,
    }
    n_params = count_params(cfg)
    print(f"      模型: {n_params/1e6:.2f}M 参数  seq={preset['seq_len']}  "
          f"每步 {(preset['micro']*preset['accum']*preset['seq_len']):,} tokens")

    tr = stage_train(root, cfg, steps, device, args.compile)
    tps = tr.get("tok_per_s_k")
    tps_abs = tps * 1000 if tps else None
    mark("train", {
        "ok": tr["loss_last"] is not None and (tr["loss_first"] or 0) > (tr["loss_last"] or 0),
        "params_m": round(n_params / 1e6, 2),
        "steps": steps,
        "loss_first": tr["loss_first"], "loss_last": tr["loss_last"],
        "tok_per_s": round(tps_abs) if tps_abs else None,
        "elapsed_s": tr.get("elapsed_s"),
        "tokens_per_step": preset["micro"] * preset["accum"] * preset["seq_len"],
    })
    report["loss_curve"] = tr["loss_curve"]

    # ---- 4. 存档校验 ----
    print("\n[4/6] 存档 / 重载")
    ck = stage_ckpt(root, device)
    ck["ok"] = ck["same_instance_repeatable"] and ck["reload_identical"]
    mark("ckpt", ck)

    # ---- 5. 生成 ----
    print("\n[5/6] 生成")
    gen = stage_generate(root, device)
    gen["ok"] = len(gen["ids"]) > 0
    mark("generate", {"ok": gen["ok"], "text": gen["text"][:120], "ids": gen["ids"][:8]})

    # ---- 6. 困惑度 ----
    print("\n[6/6] 困惑度")
    ppl = stage_ppl(root, device)
    ppl["ok"] = ppl["ppl"] > 0
    mark("ppl", ppl)

    # ---- 报告 ----
    report["finished"] = datetime.now().strftime("%Y%m%d-%H%M%S")
    with open(os.path.join(root, "report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2, default=str)

    lines = [
        f"# bring-up 报告  tier={args.tier}  device={device}",
        "",
        f"- 结论：**{'PASS' if report['ok'] else 'FAIL'}**",
        f"- 时间：{report['started']} → {report['finished']}",
        f"- 产物：`{root}`",
        "",
        "| 阶段 | 结果 | 关键指标 |",
        "|---|---|---|",
    ]
    for name, data in report["stages"].items():
        good = "✓" if data.get("ok", True) else "✗"
        key = {k: v for k, v in data.items() if k != "ok"}
        lines.append(f"| {name} | {good} | `{json.dumps(key, ensure_ascii=False, default=str)[:150]}` |")
    with open(os.path.join(root, "report.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    print(f"\n{'='*70}")
    print(f" 结论: {'PASS ✓' if report['ok'] else 'FAIL ✗'}")
    print(f" 报告: {os.path.join(root, 'report.md')}")
    print(f"{'='*70}\n")
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
