#!/usr/bin/env bash
# =============================================================================
# 20_install.sh  ——  在【内网服务器】上执行（第三步）
#
# 作用：校验离线包 → 建 venv → 离线安装 → 冒烟验证。全程不需要网络、不需要 root。
#
# 用法（在解压后的离线包目录里）：
#   bash 20_install.sh
#
# 常用开关：
#   --venv DIR        虚拟环境目录，默认 ~/venvs/llm5090
#   --python PATH     指定解释器（默认用包内 python/，没有再找 python3）
#   --req FILE        指定依赖清单（默认 requirements-core.txt）
#   --recreate        删掉已有 venv 重装
#   --skip-verify     跳过 sha256 校验（不推荐）
# =============================================================================
set -euo pipefail

BUNDLE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="${HOME}/venvs/llm5090"
PYBASE=""
REQ=""
RECREATE=0
SKIP_VERIFY=0

log()  { printf '%s\n' "$*"; }
ok()   { printf '  [ OK ] %s\n' "$*"; }
warn() { printf '  [WARN] %s\n' "$*"; }
die()  { printf '\n  [FAIL] %s\n\n' "$*" >&2; exit 1; }
step() { printf '\n[%s] %s\n' "$1" "$2"; }

while [ $# -gt 0 ]; do
  case "$1" in
    --venv)   VENV="${2:-}"; shift 2 ;;
    --python) PYBASE="${2:-}"; shift 2 ;;
    --req)    REQ="${2:-}"; shift 2 ;;
    --recreate) RECREATE=1; shift ;;
    --skip-verify) SKIP_VERIFY=1; shift ;;
    -h|--help) sed -n '2,18p' "$0"; exit 0 ;;
    *) die "未知参数: $1" ;;
  esac
done

[ -n "$REQ" ] || REQ="$BUNDLE/requirements-core.txt"

# ---------------------------------------------------------------- 0. 结构检查
step 0/6 "检查离线包结构"
[ -d "$BUNDLE/wheels" ] || die "缺少 wheels/ 目录。是不是解压错层了？应在离线包根目录执行本脚本。"
[ -d "$BUNDLE/src" ]    || die "缺少 src/ 目录"
[ -f "$REQ" ]           || die "缺少依赖清单: $REQ"
NW="$(find "$BUNDLE/wheels" -name '*.whl' | wc -l | tr -d ' ')"
[ "$NW" -gt 0 ] || die "wheels/ 是空的，离线包损坏"
ok "wheels $NW 个 / 依赖清单 $(basename "$REQ")"
if [ -f "$BUNDLE/BUNDLE_INFO.txt" ]; then
  log ""
  sed 's/^/      /' "$BUNDLE/BUNDLE_INFO.txt"
  log ""
fi

# ---------------------------------------------------------------- 1. 校验完整性
step 1/6 "校验离线包完整性"
if [ "$SKIP_VERIFY" -eq 1 ]; then
  warn "已跳过校验"
elif [ ! -f "$BUNDLE/MANIFEST.sha256" ]; then
  warn "没有 MANIFEST.sha256，跳过"
else
  # 兼容 GNU 与 BSD
  if command -v sha256sum >/dev/null 2>&1; then
    VERIFY_CMD=(sha256sum -c MANIFEST.sha256)
  else
    VERIFY_CMD=(shasum -a 256 -c MANIFEST.sha256)
  fi
  if ( cd "$BUNDLE" && "${VERIFY_CMD[@]}" >/dev/null 2>&1 ); then
    ok "全部 $(wc -l < "$BUNDLE/MANIFEST.sha256" | tr -d ' ') 个文件校验通过"
  else
    log "  校验失败的文件："
    ( cd "$BUNDLE" && "${VERIFY_CMD[@]}" 2>/dev/null | grep -v ': OK$' | head -20 ) || true
    die "离线包损坏（传输中断？）。重新拷贝一次，或加 --skip-verify 强行继续。"
  fi
fi

# ---------------------------------------------------------------- 2. 选解释器
step 2/6 "确定 Python 解释器"
if [ -z "$PYBASE" ]; then
  if [ -x "$BUNDLE/python/bin/python3" ]; then
    PYBASE="$BUNDLE/python/bin/python3"
    ok "使用离线包自带的 Python"
  else
    for c in python3.12 python3.11 python3.10 python3; do
      if command -v "$c" >/dev/null 2>&1; then PYBASE="$c"; break; fi
    done
  fi
fi
[ -n "$PYBASE" ] || die "找不到 Python。用 --python /path/to/python3 指定，或重新打包时加 --with-python"
PYV="$("$PYBASE" -c 'import sys;print("%d.%d"%sys.version_info[:2])')"
"$PYBASE" -c 'import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)' \
  || die "Python $PYV 太老，需要 3.10+"
ok "$PYBASE -> Python $PYV"

# 装之前先比对：包是按什么平台打的 vs 这台机器是什么
if [ -f "$BUNDLE/TARGET.txt" ]; then
  # shellcheck disable=SC1090
  . "$BUNDLE/TARGET.txt"
  MYVER="$("$PYBASE" -c 'import sys;print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
  MYARCH="$("$PYBASE" -c 'import platform;print(platform.machine().lower())')"
  case "$MYARCH" in amd64) MYARCH=x86_64 ;; arm64) MYARCH=aarch64 ;; esac
  TARCH="${ARCH:-unknown}"
  case "$TARCH" in amd64) TARCH=x86_64 ;; arm64) TARCH=aarch64 ;; esac

  DIFF=""
  if [ "$MYVER" != "${PYVER:-}" ]; then
    DIFF="Python 版本：包=${PYVER}  本机=$MYVER"
  fi
  if [ "$MYARCH" != "$TARCH" ]; then
    DIFF="${DIFF}${DIFF:+；}架构：包=${TARCH}  本机=$MYARCH"
  fi

  if [ -n "$DIFF" ]; then
    printf '\n  [FAIL] 离线包与这台机器不匹配 —— 装下去必然报 "from versions: none"\n\n'
    printf '         包   : Python %s / %s / %s\n' "${PYVER:-?}" "${ABI:-?}" "${TARCH}"
    printf '         本机 : Python %s / %s\n\n' "$MYVER" "$MYARCH"
    printf '  在有网机器上按本机重打（直接复制）：\n\n'
    printf '     bash 10_build_bundle.sh --for "%s %s"\n\n' "$MYVER" "$MYARCH"
    printf '  如果本机其实装了匹配的 Python，换解释器即可免重打：\n\n'
    printf '     bash 20_install.sh --python /usr/bin/python3.%s\n\n' "${PYVER##*.}"
    die "平台不匹配，未做任何变更"
  fi
  ok "平台匹配（Python $MYVER / $MYARCH）"
fi

# ---------------------------------------------------------------- 3. 磁盘
step 3/6 "检查磁盘"
MIN_DISK_GB="${MIN_DISK_GB:-12}"   # CPU 版离线包可以设小一点，如 MIN_DISK_GB=2
FREE_GB="$(df -Pk "$HOME" 2>/dev/null | awk 'NR==2{printf "%.0f", $4/1024/1024}')"
FREE_GB="${FREE_GB:-0}"
if [ "$FREE_GB" -lt "$MIN_DISK_GB" ]; then
  die "家目录只剩 ${FREE_GB}GB，需要约 ${MIN_DISK_GB}GB。清理后再试，或用 --venv 指到大盘（MIN_DISK_GB=2 可放宽）"
fi
ok "可用 ${FREE_GB} GB"

# ---------------------------------------------------------------- 4. 建 venv
step 4/6 "创建虚拟环境"
if [ "$RECREATE" -eq 1 ] && [ -d "$VENV" ]; then
  log "  → 删除旧 venv: $VENV"
  rm -rf "$VENV"
fi
if [ -d "$VENV" ]; then
  ok "复用已有 venv: $VENV"
else
  mkdir -p "$(dirname "$VENV")"
  "$PYBASE" -m venv "$VENV" || die "建 venv 失败。Debian/Ubuntu 可能需要: apt install python3-venv"
  ok "已创建: $VENV"
fi
VIP="$VENV/bin/python"
[ -x "$VIP" ] || die "venv 里没有 python，$VENV 可能不完整，用 --recreate 重来"

# ---- P0-1：真正执行 pip 的是 venv 里的 python，必须单独验它 ----
# 期望版本：优先取 TARGET.txt；老包没有 TARGET.txt 时，从 numpy 轮子名反推
WANT_PY="${PYVER:-}"
if [ -z "$WANT_PY" ]; then
  _nw="$(ls "$BUNDLE/wheels" 2>/dev/null | grep -iE '^numpy-.*-cp3[0-9]+-.*\.whl$' | head -1)"
  if [ -n "$_nw" ]; then
    _mm="$(printf '%s' "$_nw" | sed -n 's/.*-cp3\([0-9][0-9]*\)-.*/\1/p')"
    [ -n "$_mm" ] && WANT_PY="3.$_mm"
  fi
fi
VENV_PY="$("$VIP" -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null || echo unknown)"

if [ -n "$WANT_PY" ] && [ "$VENV_PY" != "$WANT_PY" ]; then
  printf '\n  [FAIL] venv 里的 Python 不是目标版本\n\n'
  printf '         venv   : %s  →  Python %s\n' "$VENV" "$VENV_PY"
  printf '         离线包 : Python %s (%s)\n\n' "$WANT_PY" "${ABI:-?}"
  printf '  真正执行 pip install 的是 venv 里的 python，不是外面的 %s。\n' "${PYV:-$WANT_PY}"
  printf '  版本不对，pip 会拒收所有 cp%s 的轮子，报 "No matching distribution"。\n\n' "${WANT_PY//./}"
  printf '  修法一（推荐，几秒）：\n     bash 20_install.sh --recreate\n'
  printf '  修法二（换干净目录）：\n     bash 20_install.sh --venv %s-r7\n\n' "$VENV"
  die "venv 版本不匹配，未做任何变更"
fi
if [ -n "$WANT_PY" ]; then
  ok "venv 里的 Python $VENV_PY 与目标一致"
else
  warn "无法确定目标 Python 版本（没有 TARGET.txt，也找不到 numpy 轮子），跳过 venv 版本校验"
fi

# ---------------------------------------------------------------- 5. 离线安装
step 5/6 "离线安装依赖（不联网）"
log "  → pip install --no-index --find-links wheels -r $(basename "$REQ")"
export PIP_NO_INDEX=1
export PIP_DISABLE_PIP_VERSION_CHECK=1

PIPLOG="$(mktemp "${TMPDIR:-/tmp}/pipinstall.XXXXXX")"
if ! "$VIP" -m pip install \
      --no-index \
      --find-links "$BUNDLE/wheels" \
      --no-warn-script-location \
      -r "$REQ" >"$PIPLOG" 2>&1; then
  tail -15 "$PIPLOG" | sed 's/^/      /'
  log ""
  if grep -qE "No matching distribution|Could not find a version" "$PIPLOG"; then
    log "  ⚠ pip 在本地 wheels 里找不到可用轮子。"
    log "    这是【离线包与这台机器不匹配】，不是网络问题。自动诊断："
    if [ -f "$BUNDLE/15_diagnose.sh" ]; then
      bash "$BUNDLE/15_diagnose.sh" --python "$VIP" --bundle "$BUNDLE" --req "$REQ" || true
    else
      log "    （离线包里没有 15_diagnose.sh，请手工比对 python 版本与架构）"
    fi
    rm -f "$PIPLOG"
    die "按上面的修复命令重新打包；也可以先试 --python 换个解释器"
  fi
  rm -f "$PIPLOG"
  die "pip 安装失败，日志见上方"
fi
rm -f "$PIPLOG"
ok "依赖安装完成"

# ---------------------------------------------------------------- 6. 冒烟
step 6/6 "冒烟验证"
"$VIP" - <<'PY'
import importlib, sys
mods = ["numpy", "yaml", "tqdm", "tokenizers", "torch"]
print(f"  Python {sys.version.split()[0]}")
missing = []
for m in mods:
    try:
        mod = importlib.import_module(m)
        v = getattr(mod, "__version__", "?")
        extra = ""
        if m == "torch":
            extra = f"  (cuda build: {getattr(mod.version, 'cuda', None)})"
        print(f"  [ OK ] {m:12s} {v}{extra}")
    except Exception as e:  # noqa: BLE001
        missing.append(m)
        print(f"  [MISS] {m:12s} {e}")
if "torch" in missing:
    print("\n  torch 缺失 = 这份离线包可能是 --torch none 打的，只能跑非训练流程")
PY

KIT="$BUNDLE/src/5090-0.5b-kit"
if [ -f "$KIT/env_check.py" ]; then
  log ""
  log "  → 运行 env_check.py"
  ( cd "$KIT" && "$VIP" env_check.py ) || warn "env_check 报了问题（不影响安装，见上面输出）"
fi

# ---------------------------------------------------------------- 完成
log ""
log "======================================================================"
log " 安装完成"
log "======================================================================"
log "  venv : $VENV"
log "  代码 : $KIT"
log ""
log "  下一步（先跑 7 秒的冒烟，确认流程通）:"
log "    bash 30_run_t0.sh"
log ""
log "  再跑 0.5B 正式档（需要 GPU，约 1.5–2 小时）:"
log "    bash 40_run_t1.sh"
log "======================================================================"
