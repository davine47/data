#!/usr/bin/env bash
# =============================================================================
# 15_diagnose.sh  ——  依赖兼容性诊断（报 "Could not find a version" 时跑这个）
#
# 对比「包里的轮子标签」和「目标解释器标签」，直接给出修复命令。
# 纯标准库，不需要联网，不需要 torch。10 秒出结果。
#
# 用法（内网服务器，在离线包根目录）：
#   bash 15_diagnose.sh
#   bash 15_diagnose.sh --python /usr/bin/python3.12
#   bash 15_diagnose.sh --python ~/venvs/llm5090/bin/python
#
# 用法（打包机上做预检，目标平台用参数指定）：
#   bash 15_diagnose.sh --target-py 3.12 --target-abi cp312 --target-arch x86_64
# =============================================================================
set -uo pipefail

BUNDLE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="python3"
REQ=""
T_PYVER=""; T_ABI=""; T_ARCH=""; T_GLIBC=""

while [ $# -gt 0 ]; do
  case "$1" in
    --python)       PY="${2:-python3}"; shift 2 ;;
    --bundle)       BUNDLE="$(cd "${2:-.}" && pwd)"; shift 2 ;;
    --req)          REQ="${2:-}"; shift 2 ;;
    --target-py)    T_PYVER="${2:-}"; shift 2 ;;
    --target-abi)   T_ABI="${2:-}"; shift 2 ;;
    --target-arch)  T_ARCH="${2:-}"; shift 2 ;;
    --target-glibc) T_GLIBC="${2:-}"; shift 2 ;;
    -h|--help)      sed -n '2,18p' "$0"; exit 0 ;;
    *) printf '未知参数: %s\n' "$1" >&2; exit 2 ;;
  esac
done

[ -d "$BUNDLE/wheels" ] || { printf '找不到 %s/wheels\n' "$BUNDLE" >&2; exit 1; }
[ -n "$REQ" ] || REQ="$BUNDLE/requirements-core.txt"
[ -f "$REQ" ] || { printf '找不到依赖清单: %s\n' "$REQ" >&2; exit 1; }

printf '\n======================================================================\n'
printf ' 依赖兼容性诊断\n'
printf '======================================================================\n'

"$PY" - "$BUNDLE/wheels" "$REQ" "$T_PYVER" "$T_ABI" "$T_ARCH" "$T_GLIBC" <<'PYEOF'
import collections
import glob
import os
import platform
import re
import sys
import sysconfig

argv = sys.argv[1:7] + [""] * 6
wdir, reqf, o_pyver, o_abi, o_arch, o_glibc = argv[:6]
OVERRIDE = bool(o_pyver or o_abi or o_arch)

W = R = G = Y = ""
if sys.stdout.isatty():
    W, R, G, Y = "\033[0m", "\033[31m", "\033[32m", "\033[33m"


def norm(n):
    return re.sub(r"[-_.]+", "_", n).lower()


def cp_ver(tag):
    """'cp312' -> (3,12)；不是 cp 标签返回 None"""
    if not tag.startswith("cp") or len(tag) < 4:
        return None
    rest = tag[2:]
    try:
        return (int(rest[0]), int(rest[1:]))
    except ValueError:
        return None


# ---------- 目标平台 ----------
tv = sys.version_info
t_py = o_abi or (f"cp{o_pyver.replace('.', '')}" if o_pyver else f"cp{tv[0]}{tv[1]}")
t_abi = o_abi or t_py
t_arch = (o_arch or platform.machine()).lower()
t_arch = {"amd64": "x86_64", "arm64": "aarch64"}.get(t_arch, t_arch)
t_pyver = o_pyver or f"{tv[0]}.{tv[1]}"
try:
    t_glibc = o_glibc or (os.confstr("CS_GNU_LIBC_VERSION") or "unknown")
except (ValueError, OSError):
    t_glibc = o_glibc or "unknown"

if OVERRIDE:
    print(f"\n 打包目标   : Python {t_pyver}  标签 {t_abi}  架构 {t_arch}  glibc {t_glibc}")
else:
    print(f"\n 目标解释器 : {sys.executable}")
    print(f"              Python {tv[0]}.{tv[1]}.{tv[2]}  标签 {t_py}  "
          f"平台 {sysconfig.get_platform()}  glibc {t_glibc}")

# ---------- 包内轮子 ----------
wheels = sorted(glob.glob(os.path.join(wdir, "*.whl")))
if not wheels:
    print(f"\n {R}[致命]{W} wheels 目录里一个 .whl 都没有")
    print(f"        {wdir}")
    sys.exit(2)

py_c, abi_c, plat_c = collections.Counter(), collections.Counter(), collections.Counter()
have = set()
for w in wheels:
    parts = os.path.basename(w)[:-4].split("-")
    if len(parts) < 5:
        continue
    have.add(norm(parts[0]))
    py_c[parts[-3]] += 1
    abi_c[parts[-2]] += 1
    for p in parts[-1].split("."):
        plat_c[p] += 1


def top(c, n=4):
    return ", ".join(f"{k}×{v}" for k, v in c.most_common(n))


print(f"\n 包内轮子   : {len(wheels)} 个")
print(f"   python 标签 : {top(py_c)}")
print(f"   abi    标签 : {top(abi_c)}")
print(f"   平台   标签 : {top(plat_c)}")

# ---------- 逐依赖 ----------
reqs = []
with open(reqf, encoding="utf-8") as f:
    for line in f:
        line = line.split("#")[0].strip()
        if not line:
            continue
        name = re.split(r"[<>=!~;\[\] ]", line)[0]
        if name:
            reqs.append(name)

aliases = {"aarch64": ("aarch64", "arm64"),
           "x86_64": ("x86_64", "amd64", "x64")}.get(t_arch, (t_arch,))


def tags_of(path):
    """拆出 (name, py, abi, platform)；文件名不合法返回 None"""
    parts = os.path.basename(path)[:-4].split("-")
    if len(parts) < 5:
        return None
    return norm(parts[0]), parts[-3], parts[-2], parts[-1]


def compatible(py, abi, plat):
    if py in (t_py, "py3", "py2.py3"):
        py_ok = True
    elif abi == "abi3" and cp_ver(py) and cp_ver(t_py):
        py_ok = cp_ver(py) <= cp_ver(t_py)      # cp310-abi3 可在 3.10+ 上装
    elif py.startswith("py3") and py[3:].isdigit() and cp_ver("cp3" + py[3:]) and cp_ver(t_py):
        py_ok = cp_ver("cp3" + py[3:]) <= cp_ver(t_py)   # 非标准但 pip 接受的 py312
    else:
        py_ok = False
    abi_ok = abi in (t_abi, t_py, "none") or (abi == "abi3" and py_ok)
    plats = plat.split(".")
    plat_ok = "any" in plats or any(a in q for q in plats for a in aliases)
    return py_ok and abi_ok and plat_ok


missing, mismatch, mixed, ok = [], [], [], []
for name in reqs:
    n = norm(name)
    mine = [w for w in wheels if tags_of(w) and tags_of(w)[0] == n]
    if not mine:
        missing.append(name)
        continue

    bad = [w for w in mine if not compatible(*tags_of(w)[1:])]
    abis = {tags_of(w)[2] for w in mine}
    # 同一个包出现多套 ABI，说明两次下载的目标不一致（core 与 sft 各自为政就会这样）
    if len(mine) > 1 and len(abis) > 1:
        mixed.append((name, sorted(os.path.basename(w) for w in mine)))
    if bad:
        mismatch.append((name, [os.path.basename(w) for w in bad]))
    else:
        ok.append(name)

print("\n 逐依赖检查（每个包的所有轮子逐个校验）：")
for name in ok:
    print(f"   {G}[ OK ]{W} {name}")
for name, files in mismatch:
    print(f"   {Y}[标签不符]{W} {name}  —— 下列轮子装不上：")
    for f in files:
        print(f"              {f}")
for name in missing:
    print(f"   {R}[缺失]{W} {name}  —— 包里完全没有它的轮子")
for name, files in mixed:
    print(f"   {R}[混装]{W} {name}  —— 同一个包存在多套 ABI，下载目标不一致：")
    for f in files:
        print(f"              {f}")

# ---------- 结论 ----------
print("\n" + "=" * 70)
if not missing and not mismatch and not mixed:
    print(f" {G}结论: 全部 {len(reqs)} 个依赖都有兼容轮子（逐轮子校验通过）。{W}")
    print("=" * 70 + "\n")
    sys.exit(0)

print(f" {R}结论: 这份离线包不是给这台机器的。{W}")
print("=" * 70)
print("\n 在【有网机器】上重新打包（参数已按本机探测好，直接复制）：")
print("\n   bash 10_build_bundle.sh \\")
print(f"     --python-version {t_pyver} --abi {t_abi} --arch {t_arch}")
if t_arch == "aarch64":
    print("\n   （aarch64/鲲鹏：确认打包机也能下到 manylinux aarch64 轮子）")
if not OVERRIDE:
    print("\n 若本机其实还装了别的 Python，可零下载直接换解释器：")
    print(f"   bash 20_install.sh --python /usr/bin/python3.{tv[1]}")
    print("   # 先看有哪些： ls /usr/bin/python3.*")
sys.exit(1)
PYEOF

RC=$?
printf '\n'
exit "$RC"
