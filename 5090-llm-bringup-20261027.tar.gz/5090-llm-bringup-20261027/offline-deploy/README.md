# 内网离线部署 · 傻瓜式操作手册

> 目标：在一台**没有外网**的服务器上，跑通 0.5B LLM 训练全流程。
> 全程 **不需要 root、不需要 sudo、不需要在外网服务器上装任何东西**。

---

## 0. 先看这张图

```
  ┌─────────────────┐        ┌──────────────────┐        ┌─────────────────┐
  │ ① 内网服务器     │        │ ② 有网机器        │        │ ③ 内网服务器     │
  │                 │        │                  │        │                 │
  │ 00_preflight.sh │──txt──▶│ 10_build_bundle  │──tgz──▶│ 20_install.sh   │
  │  (10 秒)        │        │  (10–30 分钟)     │  U盘   │  (3–5 分钟)      │
  └─────────────────┘        └──────────────────┘        └────────┬────────┘
                                                                  │
                                                         ┌────────▼────────┐
                                                         │ 30_run_t0.sh    │  7 秒
                                                         │ 40_run_t1.sh    │  2 小时
                                                         └─────────────────┘
```

**只有 5 条命令**，每个脚本都会自己检查前置条件，出错时会告诉你具体做什么。

| 文件 | 在哪跑 | 干什么 | 耗时 |
|---|---|---|---|
| `00_preflight.sh` | 内网服务器 | 探测环境，产出 `target-info.txt` | 10 秒 |
| `10_build_bundle.sh` | 有网机器 | 下载轮子 + 打包 + **自检** | 10–30 分钟 |
| `15_diagnose.sh` | 内网服务器 | **报错时用**：诊断轮子标签 vs 机器标签 | 10 秒 |
| `20_install.sh` | 内网服务器 | 校验 + 建 venv + 离线安装 | 3–5 分钟 |
| `30_run_t0.sh` | 内网服务器 | 冒烟跑通（5.5M 玩具模型） | **7 秒** |
| `40_run_t1.sh` | 内网 GPU 节点 | 0.5B 正式档 + 性能画像 | 1.5–2 小时 |

---

## 1. 内网服务器：预检

把 `offline-deploy/` 整个目录拷到内网服务器（U 盘最快），然后：

```bash
cd offline-deploy
bash 00_preflight.sh
```

你会看到类似：

```
[1/6] 系统
  [ OK ] 架构 x86_64 / 内核 Linux / Ubuntu 22.04.4 LTS
[2/6] glibc
  [ OK ] glibc 2.35
[3/6] Python
  [ OK ] python3.12 -> 3.12.3 (cp312)
[4/6] GPU 与驱动
  [ OK ] 驱动 580.65 / GPU: NVIDIA GeForce RTX 5090
[5/6] 资源
  [ OK ] 家目录可用 320 GB / 内存 251 GB
[6/6] 工具链
  [ OK ] tar / gzip / sha256sum / 家目录可写

 结论: 预检通过
```

**然后把这个文件带出内网**（复制内容到记事本、U 盘、或发给自己）：

```bash
cat target-info.txt
```

它长这样，十几行：

```ini
ARCH='x86_64'
GLIBC='2.35'
PYTHON_VER='3.12.3'
PYTHON_TAG='cp312'
GPU='NVIDIA GeForce RTX 5090'
NVIDIA_DRIVER='580.65'
PREFLIGHT_OK='1'
```

> 💡 如果预检有 `[FAIL]`，**不要继续**。最常见的两个：glibc 太老（<2.17，换系统）、没有 Python 3.10+（打包时加 `--with-python`）。

---

## 2. 有网机器：打包

把 `offline-deploy/` 和 `5090-0.5b-kit/` 放在**同一级目录**下，然后把 `target-info.txt` 也放进来：

```
工作目录/
├── offline-deploy/
├── 5090-0.5b-kit/
└── target-info.txt
```

然后一条命令：

```bash
cd offline-deploy
bash 10_build_bundle.sh --target-info ../target-info.txt
```

产物：

```
dist/offline-bundle-20261027-153000.tar.gz          约 3–5 GB
dist/offline-bundle-20261027-153000.tar.gz.sha256   几十字节
```

### 常用变体

| 场景 | 命令 |
|---|---|
| 标准（5090，cu128） | `bash 10_build_bundle.sh --target-info ../target-info.txt` |
| **只知道 Python 版本和架构** | `bash 10_build_bundle.sh --for "3.12 x86_64"`<br>⚠️ 填的是**内网服务器**的版本，不是打包机的 |
| 只有 CPU 节点，先验证流程 | `bash 10_build_bundle.sh --target-info ../target-info.txt --torch cpu`（包只有 ~300 MB） |
| 目标机没有 Python 3.10+ | 加 `--with-python` |
| 还要做 SFT | 加 `--sft`（包再大 2–3 GB） |
| 先看看会执行什么，不下载 | 加 `--dry-run` |

### 打包时它在干什么（出问题好定位）

> ⚠️ **脚本不会替你猜目标平台**。不给 `--target-info` 也不给 `--for`，它会直接拒绝退出（退出码 2）。
> 猜错一个 Python 小版本 = 4GB 白下 + 白传一趟，这是这个流程里最贵的错误。

1. 读 `target-info.txt` / `--for`，决定下载哪个平台的轮子（`manylinux2014_x86_64` + `cp312`）
2. 从 PyTorch 官方索引下 torch（cu128），从 PyPI 下其余依赖
3. 把 `5090-0.5b-kit/` 代码、安装脚本、依赖清单一起塞进去
4. 生成 `MANIFEST.sha256`，打 tar.gz，生成外层 `.sha256`

> ⚠️ 打包机最好是 **Linux x86_64**。如果像本文档这样在 macOS 上打包，脚本会自动切到"跨平台模式"（`--platform` 参数），只下二进制轮子——这能工作，但偶尔会遇到某个包只有源码分发。看到 `[WARN] 有源码包！` 就换台 Linux 机器打包。

---

## 3. 传输

**方式 A：scp（有跳板机就这么写）**

```bash
# 传到跳板机
scp dist/offline-bundle-*.tar.gz dist/offline-bundle-*.tar.gz.sha256  me@jump:/tmp/

# 再从跳板机传到目标机（在跳板机上执行）
scp /tmp/offline-bundle-*.tar.gz /tmp/offline-bundle-*.sha256  me@10.0.0.21:/data/
```

**方式 B：U 盘**

把 `offline-bundle-xxx.tar.gz` 和 `xxx.tar.gz.sha256` **两个文件都拷进去**（少一个就没法校验）。

**到了内网服务器，先校验再解压**（这一步别省，传输截断是最常见的坑）：

```bash
cd /data
sha256sum -c offline-bundle-20261027-153000.tar.gz.sha256
# 输出: offline-bundle-20261027-153000.tar.gz: OK

tar -xzf offline-bundle-20261027-153000.tar.gz
cd offline-bundle-20261027-153000
```

---

## 4. 内网服务器：安装

```bash
cd /data/offline-bundle-20261027-153000
bash 20_install.sh
```

它做 6 件事，每件都会打印：

```
[0/6] 检查离线包结构      → wheels 127 个 / 依赖清单 requirements-core.txt
[1/6] 校验离线包完整性    → 全部 128 个文件校验通过
[2/6] 确定 Python 解释器  → /usr/bin/python3.12 -> Python 3.12
[3/6] 检查磁盘            → 可用 320 GB
[4/6] 创建虚拟环境        → ~/venvs/llm5090
[5/6] 离线安装依赖        → pip install --no-index --find-links wheels
[6/6] 冒烟验证            → numpy / yaml / tqdm / tokenizers / torch 版本
```

默认装到 `~/venvs/llm5090`。想换地方：

```bash
bash 20_install.sh --venv /data/venvs/llm5090
```

装错了想重来：

```bash
bash 20_install.sh --recreate
```

---

## 5. 跑通

### 5.1 先跑 7 秒的冒烟（必做）

```bash
bash 30_run_t0.sh
```

```
[1/6] 环境      ✓
[2/6] 数据      ✓ 10,010 篇 / 914,254 tokens / 词表 693→4096
[3/6] 训练      ✓ 5.48M 参数 / loss 8.3807 → 5.7798
[4/6] 存档      ✓ 重载逐位一致
[5/6] 生成      ✓
[6/6] 困惑度    ✓ ppl 264.68

 结论: PASS ✓
```

**看到 PASS 就说明整条管线是通的**：分词、打包、前向、反向、优化器、存档、重载、采样、评估，全都跑过了。

> 有 GPU 的话可以加 `--device cuda`，7 秒变 3 秒，数字更有参考性。

### 5.2 再跑正式档

```bash
bash 40_run_t1.sh
```

约 1.5–2 小时，产出：

```
src/5090-0.5b-kit/runs/bringup_full_xxx/
├── report.md        ← 阶段 PASS/FAIL + 关键指标
├── profile.json     ← tok/s、MFU、时间分解、显存峰值
└── trace.json       ← chrome://tracing 打开看时间线
```

**把这三个文件带回外网分析就够了。**

想快速试（20 分钟）：

```bash
bash 40_run_t1.sh --tokens 20000000 --steps 60
```

用你自己的语料：

```bash
bash 40_run_t1.sh --corpus '/data/clean/*.jsonl' --corpus-mb 60
```

---

## 6. 照着做：三张速查表

### 6.1 最短路径（只有 3 条命令）

```bash
# 内网
bash 00_preflight.sh && cat target-info.txt
# 外网
bash 10_build_bundle.sh --target-info target-info.txt
# 内网（传完包之后）
tar -xzf offline-bundle-*.tar.gz && cd offline-bundle-* && bash 20_install.sh && bash 30_run_t0.sh
```

### 6.2 报错怎么办

| 现象 | 原因 | 解决 |
|---|---|---|
| `[FAIL] 目标必须是 Linux；当前是 Darwin` | 在 Mac/WSL 上跑了预检 | 预检必须在内网 **Linux** 服务器上跑 |
| `[FAIL] 读不到 glibc` | Alpine/musl 系统 | 本方案不支持，换 Ubuntu/CentOS |
| `[FAIL] 没找到 python3` | 系统没装 Python | 打包时加 `--with-python` |
| `[FAIL] 缺 venv 模块` | Debian 系没装 | `apt install python3-venv`（这一步才需要 sudo） |
| 打包时 `pip download` 卡住 | 网络/代理 | 设 `export https_proxy=...` 后重跑 |
| `[WARN] 有源码包！` | 那个包没有目标平台轮子 | 换台 Linux x86_64 打包，或降该包版本 |
| 安装时 `Could not find a version that satisfies ... (from versions: none)` | **轮子标签与目标 Python/架构不匹配**（不是网络问题） | 跑 `bash 15_diagnose.sh`，它会直接打印该用哪条命令重打包 |
| 填了 `--target-info` 还是同样的错 | **v1 脚本的 bug**：`native` 模式没把目标 Python 传给 pip，下成了构建机的轮子 | 老脚本加 `--mode cross` 强制生效；新脚本已修（`10_build_bundle.sh:195`） |
| 安装时 `is not a supported wheel` | 架构打错了（x86_64 vs aarch64） | 核对预检里的 `ARCH` |
| `校验失败的文件` | 传输截断 | 重新拷贝，别用 `--skip-verify` |
| `no kernel image is available` | torch 不是 cu128 | 重新打包时确认 `--torch cu128`，且驱动 ≥ 570 |
| `torch 看不到 CUDA` | 在登录节点上跑 | 把包和 `40_run_t1.sh` 拷到 GPU 节点 |
| 磁盘不足 12 GB | venv + torch 峰值 | 用 `--venv /大盘/路径` |

> **关于 `from versions: none`**
> 这句话的意思是"本地 wheels 里一个可用候选都没有"。`20_install.sh` 现在会自动检测这种情况，
> 并直接调用 `15_diagnose.sh` 打印修复命令。手工诊断：
> ```bash
> bash 15_diagnose.sh                        # 用当前 python3
> bash 15_diagnose.sh --python ~/venvs/llm5090/bin/python
> ```
> 输出会告诉你：目标解释器是什么标签、包里轮子是什么标签、哪个依赖缺失、以及**该用哪条 `10_build_bundle.sh` 命令重打**。
>
> 最快的零下载修复：如果目标机其实装了**多个 Python**，直接指到匹配的那个：
> ```bash
> ls /usr/bin/python3.*
> bash 20_install.sh --python /usr/bin/python3.12
> ```

### 6.3 包里到底有什么

```
offline-bundle-20261027-153000/
├── BUNDLE_INFO.txt      构建信息（目标平台、torch 变体、轮子数量）
├── MANIFEST.sha256      128 个文件的校验和
├── wheels/              pip 轮子（含 torch + nvidia-* 运行库）
├── src/5090-0.5b-kit/   训练代码
├── requirements-core.txt
├── 20_install.sh
├── 30_run_t0.sh
└── 40_run_t1.sh
```

**不含**：CUDA Toolkit（不需要，torch 轮子自带运行时）、NVIDIA 驱动（服务器必须已装）、语料（T1 默认用合成语料，完全离线）。

---

## 7. 三个容易搞混的点

**① 驱动 vs CUDA Toolkit**
服务器只需要**驱动 ≥ 570**（`nvidia-smi` 能跑就行）。CUDA Toolkit **不用装**——torch 的 cu128 轮子里已经带了 `nvidia-cublas-cu12` 这些运行时库，这就是离线包有 3–5 GB 的原因。

**② 内网服务器 vs GPU 节点**
很多集群是"登录节点无卡 + 计算节点有卡"。预检在登录节点跑没问题（能拿到系统和 Python 信息），但 `40_run_t1.sh` 必须在**有卡的节点**跑。包放在共享存储（NFS/Lustre）上，两个节点都能访问最省事。

**③ 为什么还要单独打包，不能直接拷 venv**
venv 里写死了绝对路径，换机器就废。而且 macOS/不同 glibc 的二进制不能混用。所以走"下轮子 → 目标机本地装"这条路，这是唯一可靠的方式。

---

## 8. 附：如果连 `offline-deploy/` 都传不进去

把这一页的内容抄成文件，或者只拷 5 个 `.sh` + 2 个 `requirements*.txt`（总共不到 50 KB），然后：

```bash
# 内网服务器上，手动造一个最小包
mkdir -p mydeploy && cd mydeploy
# 把 5 个 sh 和 requirements 放进来
bash 00_preflight.sh
```

`10_build_bundle.sh` 需要的 `5090-0.5b-kit/` 如果太大，可以先只打核心三件套（`bringup.py`/`pretrain.py`/`pack_corpus.py` + `build_tokenizer.py` + `env_check.py`），总共 60 KB。

---

*所有脚本已在 macOS 上做过语法检查与 mini 包的端到端验证（打包 → 校验 → 解压 → 离线安装 → 冒烟）。目标机为 Linux 的完整链路需在真实内网环境首次执行时确认，遇到报错按 §6.2 处理。*
