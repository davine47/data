#!/usr/bin/env bash
# =============================================================================
# 40_run_t1.sh  ——  正式档（0.5B）+ 性能画像
#
# 默认用合成语料（完全离线），跑 100M tokens 的预训练，然后出 profiler 报告。
# 有 GPU 时约 1.5–2 小时；没 GPU 会非常慢，不建议。
#
# 用法：
#   bash 40_run_t1.sh
#   bash 40_run_t1.sh --corpus '/data/clean/*.jsonl' --corpus-mb 60
#   bash 40_run_t1.sh --tokens 20000000 --steps 60     # 快速版，约 20 分钟
#   bash 40_run_t1.sh --no-profile                     # 只训练，不做画像
# =============================================================================
set -euo pipefail

BUNDLE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="${VENV:-$HOME/venvs/llm5090}"
DEVICE="cuda"
CORPUS=""
CORPUS_MB=""
TOKENS=""
STEPS=""
PROFILE=1
PYOVERRIDE=""

while [ $# -gt 0 ]; do
  case "$1" in
    --device)    DEVICE="${2:-cuda}"; shift 2 ;;
    --venv)      VENV="${2:-}"; shift 2 ;;
    --python)    PYOVERRIDE="${2:-}"; shift 2 ;;
    --corpus)    CORPUS="${2:-}"; shift 2 ;;
    --corpus-mb) CORPUS_MB="${2:-}"; shift 2 ;;
    --tokens)    TOKENS="${2:-}"; shift 2 ;;
    --steps)     STEPS="${2:-}"; shift 2 ;;
    --no-profile) PROFILE=0; shift ;;
    -h|--help)   sed -n '2,17p' "$0"; exit 0 ;;
    *) printf '未知参数: %s\n' "$1" >&2; exit 2 ;;
  esac
done

PY="${PYOVERRIDE:-$VENV/bin/python}"
KIT="$BUNDLE/src/5090-0.5b-kit"
LOGDIR="${LOGDIR:-$HOME}"
[ -w "$LOGDIR" ] || LOGDIR="$BUNDLE"
LOG="$LOGDIR/bringup_t1.log"

[ -x "$PY" ] || { printf '\n  [FAIL] 找不到 %s，先跑 20_install.sh\n\n' "$PY" >&2; exit 1; }
[ -f "$KIT/bringup.py" ] || { printf '\n  [FAIL] 找不到 %s\n\n' "$KIT/bringup.py" >&2; exit 1; }

if ! "$PY" -c 'import torch' >/dev/null 2>&1; then
  printf '\n  [FAIL] 这个 Python 里没有 torch：%s\n  先跑 20_install.sh\n\n' "$PY" >&2
  exit 1
fi

if [ "$DEVICE" = "cuda" ]; then
  if ! "$PY" -c 'import torch,sys; sys.exit(0 if torch.cuda.is_available() else 1)' 2>/dev/null; then
    printf '\n  [FAIL] torch 看不到 CUDA。这台机器没有 GPU 或驱动不对。\n'
    printf '         可以用 --device cpu 跑，但会非常慢（几小时起步，不建议）。\n'
    printf '         或者把本脚本和离线包拷到 GPU 节点上执行。\n\n'
    exit 1
  fi
  "$PY" -c 'import torch; print("  GPU:", torch.cuda.get_device_name(0),
             torch.cuda.get_device_properties(0).total_memory//1024**3, "GiB")'
fi

ARGS=(--tier full --device "$DEVICE")
if [ -n "$CORPUS" ];    then ARGS+=(--corpus "$CORPUS");    fi
if [ -n "$CORPUS_MB" ]; then ARGS+=(--corpus-mb "$CORPUS_MB"); fi
if [ -n "$TOKENS" ];    then ARGS+=(--tokens "$TOKENS");    fi
if [ -n "$STEPS" ];     then ARGS+=(--steps "$STEPS");      fi

printf '\n== T1 正式档  device=%s ==\n' "$DEVICE"
printf '   日志: %s\n' "$LOG"
printf '   预计: 1.5–2 小时（5090，100M tokens）\n\n'

cd "$KIT"
set +e
"$PY" bringup.py "${ARGS[@]}" 2>&1 | tee "$LOG"
RC="${PIPESTATUS[0]}"
set -e

if [ "$RC" -ne 0 ]; then
  printf '\n  T1 失败（退出码 %s）。看日志:\n    tail -60 %s\n\n' "$RC" "$LOG"
  exit "$RC"
fi

RUN="$(ls -dt "$KIT"/runs/bringup_full_* 2>/dev/null | head -1)"
printf '\n  报告: %s/report.md\n' "$RUN"

if [ "$PROFILE" -eq 1 ] && [ -f "$RUN/config.yaml" ]; then
  printf '\n== 性能画像 ==\n'
  "$PY" profiler.py --config "$RUN/config.yaml" --device "$DEVICE" --steps 20 --trace 2>&1 \
    | tee "$LOGDIR/profile.log"
  printf '\n  画像结果: %s/profile.json\n' "$RUN"
fi

printf '\n  下一步：把下面三个文件带回分析\n'
printf '    %s/report.md\n' "$RUN"
printf '    %s/profile.json\n' "$RUN"
printf '    %s/trace.json   （--trace 生成，可用 chrome://tracing 打开）\n\n' "$RUN"
