#!/usr/bin/env bash
# =============================================================================
# 00_preflight.sh  ——  在内网服务器上执行（第一步）
#
# 作用：探测目标机环境，产出 target-info.txt，供有网机器打包时使用。
# 不需要网络、不需要 root、不安装任何东西。
#
# 用法：
#   bash 00_preflight.sh
#   cat target-info.txt          # 把这个文件带出去（U盘/跳板机/复制内容）
# =============================================================================
set -uo pipefail

OUT="${1:-target-info.txt}"
FAIL=0

say()  { printf '%s\n' "$*"; }
ok()   { printf '  [ OK ] %s\n' "$*"; }
bad()  { printf '  [FAIL] %s\n' "$*"; FAIL=1; }
warn() { printf '  [WARN] %s\n' "$*"; }
# 去掉单引号，保证写出的 KEY='value' 可以被 source
san()  { printf '%s' "${1:-}" | tr -d "'"; }

say "======================================================================"
say " 5090 / 0.5B 训练环境预检"
say " 时间: $(date '+%Y-%m-%d %H:%M:%S')"
say "======================================================================"

# ---------------------------------------------------------------- 1. 架构 / OS
say ""
say "[1/6] 系统"
ARCH="$(uname -m)"
KERNEL="$(uname -s)"
OS_NAME="unknown"
OS_VER="unknown"
if [ -r /etc/os-release ]; then
  # shellcheck disable=SC1091
  . /etc/os-release 2>/dev/null || true
  OS_NAME="${PRETTY_NAME:-${NAME:-unknown}}"
  OS_VER="${VERSION_ID:-unknown}"
fi
ok "架构 $ARCH / 内核 $KERNEL / $OS_NAME"
[ "$KERNEL" = "Linux" ] || bad "目标必须是 Linux；当前是 $KERNEL"

# ---------------------------------------------------------------- 2. glibc
say ""
say "[2/6] glibc"
GLIBC="$(getconf GNU_LIBC_VERSION 2>/dev/null | awk '{print $2}')"
if [ -z "${GLIBC:-}" ]; then
  bad "读不到 glibc（Alpine/musl？）。本方案只支持 glibc 系统。"
  GLIBC="0"
else
  ok "glibc $GLIBC"
  GL_MAJ="${GLIBC%%.*}"
  GL_MIN="${GLIBC#*.}"; GL_MIN="${GL_MIN%%.*}"
  if [ "${GL_MAJ:-0}" -lt 2 ] || { [ "${GL_MAJ:-0}" -eq 2 ] && [ "${GL_MIN:-0}" -lt 17 ]; }; then
    bad "glibc < 2.17，绝大多数 manylinux 轮子装不上"
  elif [ "${GL_MAJ:-0}" -eq 2 ] && [ "${GL_MIN:-0}" -lt 28 ]; then
    warn "glibc < 2.28：只能用 manylinux2014 轮子，torch 版本可能需要回退"
  fi
fi

# ---------------------------------------------------------------- 3. Python
say ""
say "[3/6] Python"
PY=""
for c in python3.12 python3.11 python3.10 python3 python; do
  if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done
PY_VER=""; PY_TAG=""; PY_OK=0
if [ -z "$PY" ]; then
  bad "没找到 python3（需 3.10+）。可在打包时加 --with-python 附带一个。"
else
  PY_VER="$("$PY" -c 'import sys;print("%d.%d.%d"%sys.version_info[:3])' 2>/dev/null)"
  PY_TAG="$("$PY" -c 'import sys;print("cp%d%d"%(sys.version_info[0],sys.version_info[1]))' 2>/dev/null)"
  ok "$PY -> $PY_VER ($PY_TAG)"
  case "$PY_VER" in
    3.10.*|3.11.*|3.12.*|3.13.*) PY_OK=1 ;;
    *) bad "版本 $PY_VER 不在 3.10–3.13，可能没有对应 torch 轮子" ;;
  esac
  if ! "$PY" -c 'import venv' >/dev/null 2>&1; then
    bad "缺 venv 模块（Debian/Ubuntu 需 apt install python3-venv）"
  fi
fi

# ---------------------------------------------------------------- 4. GPU / 驱动
say ""
say "[4/6] GPU 与驱动"
GPU="none"; DRIVER="none"
if command -v nvidia-smi >/dev/null 2>&1; then
  DRIVER="$(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null | head -1 | tr -d ' \r')"
  GPU="$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1 | sed 's/^ *//;s/ *$//')"
  if [ -n "${DRIVER:-}" ]; then
    ok "驱动 $DRIVER / GPU: ${GPU:-unknown}"
    case "$DRIVER" in
      [0-9]*)
        if [ "${DRIVER%%.*}" -lt 570 ]; then
          warn "驱动主版本 < 570，sm_120 (Blackwell) 可能不被支持；建议 580+"
        fi
        ;;
    esac
  else
    warn "nvidia-smi 存在但读不到信息"
  fi
else
  warn "没有 nvidia-smi：本机没有 NVIDIA 驱动"
  warn "  → 可以跑 T0（CPU 冒烟）；T1 需在 GPU 节点上执行"
fi

# ---------------------------------------------------------------- 5. 资源
say ""
say "[5/6] 资源"
DISK_FREE="$(df -Pk "$HOME" 2>/dev/null | awk 'NR==2{printf "%.0f", $4/1024/1024}')"
DISK_FREE="${DISK_FREE:-0}"
MEM_GB="$(awk '/MemTotal/{printf "%.0f", $2/1024/1024}' /proc/meminfo 2>/dev/null)"
MEM_GB="${MEM_GB:-0}"
[ "${MEM_GB:-0}" -eq 0 ] 2>/dev/null && MEM_GB="unknown"
ok "家目录可用 ${DISK_FREE} GB / 内存 ${MEM_GB} GB"
if [ "$DISK_FREE" -lt 15 ]; then
  bad "磁盘不足 15GB：解包 + 装 torch 峰值约需 12GB"
fi

# ---------------------------------------------------------------- 6. 工具
say ""
say "[6/6] 工具链"
for t in tar gzip; do
  if command -v "$t" >/dev/null 2>&1; then ok "$t"; else bad "缺少 $t"; fi
done
if command -v sha256sum >/dev/null 2>&1; then
  ok "sha256sum"
elif command -v shasum >/dev/null 2>&1; then
  ok "shasum（代替 sha256sum）"
else
  bad "缺少 sha256sum / shasum，无法校验离线包"
fi
if [ -w "$HOME" ]; then
  ok "家目录可写（全程不需要 sudo）"
else
  warn "家目录不可写：安装时用 --venv 指到你有权限的目录"
fi

# ---------------------------------------------------------------- 输出
say ""
say "======================================================================"
if [ "$FAIL" -eq 0 ]; then
  say " 结论: 预检通过"
else
  say " 结论: 有 FAIL 项，先解决再往下走"
fi
say "======================================================================"

cat > "$OUT" <<EOF
# target-info.txt — 由 00_preflight.sh 生成于 $(date '+%Y-%m-%d %H:%M:%S')
ARCH='$(san "$ARCH")'
KERNEL='$(san "$KERNEL")'
OS_NAME='$(san "$OS_NAME")'
OS_VER='$(san "$OS_VER")'
GLIBC='$(san "$GLIBC")'
PYTHON_BIN='$(san "$PY")'
PYTHON_VER='$(san "$PY_VER")'
PYTHON_TAG='$(san "$PY_TAG")'
PYTHON_OK='$PY_OK'
GPU='$(san "$GPU")'
NVIDIA_DRIVER='$(san "$DRIVER")'
DISK_FREE_GB='$(san "$DISK_FREE")'
MEM_GB='$(san "$MEM_GB")'
PREFLIGHT_OK='$([ "$FAIL" -eq 0 ] && echo 1 || echo 0)'
EOF

say ""
say "已写出: $OUT"
say ""
say "下一步（在【有网机器】上执行）:"
say "    bash 10_build_bundle.sh --target-info $OUT"
exit "$FAIL"
