#!/usr/bin/env bash
# =============================================================================
# 30_run_t0.sh  ——  冒烟跑通（任何机器，约 7 秒）
#
# 不需要 GPU、不需要语料、不需要联网：会用合成语料把
# 环境 → 数据 → 分词 → 打包 → 训练 → 存档 → 生成 → 困惑度 全跑一遍。
#
# 用法：
#   bash 30_run_t0.sh
#   bash 30_run_t0.sh --device cuda      # 有卡就上卡，数字更有参考性
#   bash 30_run_t0.sh --steps 50         # 多跑几步看 loss 曲线
# =============================================================================
set -euo pipefail

BUNDLE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="${VENV:-$HOME/venvs/llm5090}"
DEVICE="cpu"
PYOVERRIDE=""
EXTRA=()

while [ $# -gt 0 ]; do
  case "$1" in
    --device) DEVICE="${2:-cpu}"; shift 2 ;;
    --venv)   VENV="${2:-}"; shift 2 ;;
    --python) PYOVERRIDE="${2:-}"; shift 2 ;;
    --steps)  EXTRA+=(--steps "${2:-}"); shift 2 ;;
    -h|--help) sed -n '2,14p' "$0"; exit 0 ;;
    *) printf '未知参数: %s\n' "$1" >&2; exit 2 ;;
  esac
done

PY="${PYOVERRIDE:-$VENV/bin/python}"
KIT="$BUNDLE/src/5090-0.5b-kit"
LOGDIR="${LOGDIR:-$HOME}"
[ -w "$LOGDIR" ] || LOGDIR="$BUNDLE"
LOG="$LOGDIR/bringup_t0.log"

[ -x "$PY" ] || { printf '\n  [FAIL] 找不到 %s\n  先执行: bash 20_install.sh\n\n' "$PY" >&2; exit 1; }
[ -f "$KIT/bringup.py" ] || { printf '\n  [FAIL] 找不到 %s\n\n' "$KIT/bringup.py" >&2; exit 1; }

# 提前给出人话错误，而不是甩一段 traceback
if ! "$PY" -c 'import torch' >/dev/null 2>&1; then
  printf '\n  [FAIL] 这个 Python 里没有 torch：%s\n' "$PY"
  printf '         离线包可能是 --torch none 打的，或者 venv 装错了。\n'
  printf '         检查: %s -c "import torch; print(torch.__version__)"\n\n' "$PY" >&2
  exit 1
fi

printf '\n== T0 冒烟  device=%s ==\n' "$DEVICE"
printf '   日志: %s\n\n' "$LOG"

cd "$KIT"
set +e
"$PY" bringup.py --tier toy --device "$DEVICE" ${EXTRA[@]+"${EXTRA[@]}"} 2>&1 | tee "$LOG"
RC="${PIPESTATUS[0]}"
set -e

printf '\n'
if [ "$RC" -eq 0 ]; then
  printf '  T0 通过。报告: %s\n' "$(ls -dt "$KIT"/runs/bringup_toy_* 2>/dev/null | head -1)/report.md"
  printf '  下一步: bash 40_run_t1.sh\n\n'
else
  printf '  T0 失败（退出码 %s）。看 %s 最后 40 行：\n' "$RC" "$LOG"
  printf '    tail -40 %s\n\n' "$LOG"
  exit "$RC"
fi
