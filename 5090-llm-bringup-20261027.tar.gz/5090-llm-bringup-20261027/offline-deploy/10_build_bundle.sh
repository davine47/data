#!/usr/bin/env bash
# =============================================================================
# 10_build_bundle.sh  ——  在【有网机器】上执行（第二步）
#
# 作用：按目标机信息，把 pip 轮子 + 代码 + 安装脚本打成一个离线包。
# 产物：offline-bundle-<时间>.tar.gz 和对应的 .sha256
#
# 用法（推荐，用预检文件）：
#   bash 10_build_bundle.sh --target-info target-info.txt
#
# 用法（没带预检文件，按默认 x86_64 / py3.12 / cu128 打）：
#   bash 10_build_bundle.sh
#
# 常用开关：
#   --torch cu128|cpu|none   默认 cu128（5090 需要 cu128 及以上）
#   --sft                    额外打包 SFT 依赖（LLaMA-Factory，+约 3GB）
#   --with-python            附带一个独立 Python（目标机没有 3.10+ 时用）
#   --outdir DIR             产物目录，默认 ./dist
#   --dry-run                只打印命令，不真正下载
# =============================================================================
set -euo pipefail

# ----------------------------------------------------------------- 默认值
TARGET_INFO=""
FOR=""
ALLOW_DEFAULT=0
ARCH="x86_64"
PYVER="3.12"
ABI=""
GLIBC="2.28"
TORCH="cu128"
WITH_SFT=0
WITH_PYTHON=0
SKIP_CHECK=0
MODE="auto"
OUTDIR="./dist"
REQ=""
SRC=""
DRY=0

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ----------------------------------------------------------------- 输出
log()  { printf '%s\n' "$*"; }
ok()   { printf '  [ OK ] %s\n' "$*"; }
warn() { printf '  [WARN] %s\n' "$*"; }
die()  { printf '\n  [FAIL] %s\n\n' "$*" >&2; exit 1; }
step() { printf '\n[%s] %s\n' "$1" "$2"; }

# ----------------------------------------------------------------- 参数解析
while [ $# -gt 0 ]; do
  case "$1" in
    --target-info) TARGET_INFO="${2:-}"; shift 2 ;;
    --for)         FOR="${2:-}"; shift 2 ;;
    --assume-default) ALLOW_DEFAULT=1; shift ;;
    --arch)        ARCH="${2:-}"; shift 2 ;;
    --python-version) PYVER="${2:-}"; shift 2 ;;
    --abi)         ABI="${2:-}"; shift 2 ;;
    --torch)       TORCH="${2:-}"; shift 2 ;;
    --sft)         WITH_SFT=1; shift ;;
    --with-python) WITH_PYTHON=1; shift ;;
    --mode)        MODE="${2:-}"; shift 2 ;;
    --outdir)      OUTDIR="${2:-}"; shift 2 ;;
    --req)         REQ="${2:-}"; shift 2 ;;
    --src)         SRC="${2:-}"; shift 2 ;;
    --skip-check)  SKIP_CHECK=1; shift ;;
    --dry-run)     DRY=1; shift ;;
    -h|--help)     sed -n '2,22p' "$0"; exit 0 ;;
    *) die "未知参数: $1（用 --help 查看）" ;;
  esac
done

# ----------------------------------------------------------------- --for "3.10 x86_64"
if [ -n "$FOR" ]; then
  PYVER="$(printf '%s' "$FOR" | awk '{print $1}')"
  _arch="$(printf '%s' "$FOR" | awk '{print $2}')"
  [ -n "$_arch" ] && ARCH="$_arch"
  case "$PYVER" in
    [0-9].[0-9]|[0-9].[0-9][0-9]) : ;;
    *) die "--for 格式应为 \"3.12 x86_64\"（填内网服务器的版本，不是本机），收到: $FOR" ;;
  esac
  ok "目标（手工指定）: Python $PYVER / $ARCH"
  HOST_PY="$(python3 -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null)"
  if [ -n "${HOST_PY:-}" ] && [ "$PYVER" = "$HOST_PY" ]; then
    warn "--for 指的是【内网服务器】的版本，不是本机；而本机也是 $HOST_PY"
    warn "  请确认你没填反（服务器 python3 -V 是多少？）"
  fi
fi

# ----------------------------------------------------------------- 不允许猜
if [ -z "$TARGET_INFO" ] && [ -z "$FOR" ] && [ "$ALLOW_DEFAULT" -eq 0 ]; then
  cat >&2 <<'EOM'

  [FAIL] 没有指定目标平台。参数猜错 = 白下 4GB + 白传一趟。

  二选一：
    1) 把 00_preflight.sh 的产物带出来（推荐）
         bash 10_build_bundle.sh --target-info target-info.txt
    2) 在服务器上跑一行，把输出原样粘进来
         python3 -c "import sys,platform;print(f'{sys.version_info.major}.{sys.version_info.minor} {platform.machine()}')"
         bash 10_build_bundle.sh --for "3.12 x86_64"
         （--for 填的是【内网服务器】的版本，不是打包机的）

  确实要沿用默认值 3.12 / x86_64 / cu128：加 --assume-default

EOM
  exit 2
fi

# ----------------------------------------------------------------- 读预检文件
if [ -n "$TARGET_INFO" ]; then
  [ -f "$TARGET_INFO" ] || die "找不到预检文件: $TARGET_INFO"
  # shellcheck disable=SC1090
  . "$TARGET_INFO"
  ARCH="${ARCH:-x86_64}"
  PYVER="$(printf '%s' "${PYTHON_VER:-3.12}" | cut -d. -f1,2)"
  [ -n "${PYTHON_TAG:-}" ] && ABI="$PYTHON_TAG"
  GLIBC="${GLIBC:-2.17}"
  if [ "${PREFLIGHT_OK:-1}" != "1" ]; then
    warn "预检文件里 PREFLIGHT_OK=$PREFLIGHT_OK，目标机可能有硬伤，继续打包但安装大概率失败"
  fi
  ok "已读取目标机: arch=$ARCH python=$PYVER glibc=$GLIBC gpu=${GPU:-none} driver=${NVIDIA_DRIVER:-none}"
fi

# Python 全版本 -> tag
PY_MAJOR="${PYVER%%.*}"
PY_MINOR="${PYVER#*.}"
PY_MINOR="${PY_MINOR%%.*}"
[ -n "$ABI" ] || ABI="cp${PY_MAJOR}${PY_MINOR}"

# ----------------------------------------------------------------- 基础检查
step 1/7 "检查打包机"

command -v python3 >/dev/null 2>&1 || die "需要 python3 来执行 pip download"
python3 -c 'import sys; sys.exit(0 if sys.version_info>=(3,8) else 1)' \
  || die "python3 太老（需 3.8+，仅用于跑 pip，不影响目标机）"
PIPV="$(python3 -m pip --version 2>/dev/null | awk '{print $2}')"
[ -n "$PIPV" ] || die "没有 pip"
ok "打包机 python $(python3 -V 2>&1 | awk '{print $2}') / pip $PIPV"

HOST_OS="$(uname -s)"
HOST_ARCH="$(uname -m)"
if [ "$MODE" = "auto" ]; then
  if [ "$HOST_OS" = "Linux" ] && [ "$HOST_ARCH" = "$ARCH" ]; then
    MODE="native"
  else
    MODE="cross"
  fi
fi
ok "模式: $MODE  （$HOST_OS/$HOST_ARCH → Linux/$ARCH）"
if [ "$MODE" = "cross" ]; then
  warn "跨平台打包：只下载二进制轮子（--only-binary=:all:），任何纯源码包都会失败"
fi

case "$TORCH" in
  cu128) TORCH_INDEX="https://download.pytorch.org/whl/cu128" ;;
  cu126) TORCH_INDEX="https://download.pytorch.org/whl/cu126" ;;
  cpu)   TORCH_INDEX="https://download.pytorch.org/whl/cpu" ;;
  none)  TORCH_INDEX="" ;;
  *)     die "--torch 只能是 cu128 / cu126 / cpu / none" ;;
esac

SRC="${SRC:-$SCRIPT_DIR/../5090-0.5b-kit}"
[ -d "$SRC" ] || die "找不到代码目录: $SRC"
[ -n "$REQ" ] || REQ="$SCRIPT_DIR/requirements-core.txt"
[ -f "$REQ" ] || die "找不到依赖清单: $REQ"
ok "代码: $(cd "$SRC" && pwd)"
ok "依赖: $REQ"

# ----------------------------------------------------------------- 准备目录
step 2/7 "准备打包目录"

TS="$(date '+%Y%m%d-%H%M%S')"
NAME="offline-bundle-$TS"
WORK="$(mktemp -d "${TMPDIR:-/tmp}/buildbundle.XXXXXX")"
BUNDLE="$WORK/$NAME"
mkdir -p "$BUNDLE/wheels" "$BUNDLE/src"

cleanup() { rm -rf "$WORK"; }
trap cleanup EXIT

# ----------------------------------------------------------------- 处理 torch=none
REQ_USE="$REQ"
if [ "$TORCH" = "none" ]; then
  REQ_USE="$WORK/req-notorch.txt"
  grep -viE '^\s*torch' "$REQ" > "$REQ_USE" || true
  ok "已移除 torch，只打纯 Python 依赖"
fi

# ----------------------------------------------------------------- 下载轮子
step 3/7 "下载 pip 轮子（这是最慢的一步）"

# ---- 目标平台参数：core 与 sft 共用同一份，禁止各写一套 ----
TARGET_PIP_ARGS=( --python-version "$PYVER" --implementation cp --abi "$ABI" )
log "  → 下载目标: py$PYVER / $ABI / $ARCH  (mode=$MODE)"

if [ "$MODE" = "cross" ]; then
  case "$ARCH" in
    x86_64) PLATS=( "--platform" "manylinux2014_x86_64" ) ;;
    aarch64|arm64) PLATS=( "--platform" "manylinux2014_aarch64" ) ;;
    *) die "不支持的架构: $ARCH" ;;
  esac
  # glibc >= 2.28 才允许 manylinux_2_28 轮子
  GL_MAJ="${GLIBC%%.*}"; GL_MIN="${GLIBC#*.}"; GL_MIN="${GL_MIN%%.*}"
  if [ "${GL_MAJ:-2}" -gt 2 ] || { [ "${GL_MAJ:-2}" -eq 2 ] && [ "${GL_MIN:-0}" -ge 28 ]; }; then
    if [ "$ARCH" = "x86_64" ]; then
      PLATS+=( "--platform" "manylinux_2_28_x86_64" )
    else
      PLATS+=( "--platform" "manylinux_2_28_aarch64" )
    fi
  fi
  TARGET_PIP_ARGS+=("${PLATS[@]}")
fi

PIP_ARGS=(-m pip download -r "$REQ_USE" -d "$BUNDLE/wheels"
          --only-binary=:all: --no-cache-dir --progress-bar off
          "${TARGET_PIP_ARGS[@]}")
if [ -n "$TORCH_INDEX" ]; then
  PIP_ARGS+=(--index-url "$TORCH_INDEX" --extra-index-url "https://pypi.org/simple")
fi

if [ "$DRY" -eq 1 ]; then
  log "  [dry-run] python3 ${PIP_ARGS[*]}"
else
  python3 "${PIP_ARGS[@]}" || die "下载失败。常见原因：目标 Python 版本没有对应轮子 / 网络 / 需要代理"
fi

if [ "$WITH_SFT" -eq 1 ] && [ "$DRY" -eq 0 ]; then
  log "  → 追加 SFT 依赖（LLaMA-Factory，较大）"
  SFT_REQ="$SCRIPT_DIR/requirements-sft.txt"
  python3 -m pip download -r "$SFT_REQ" -d "$BUNDLE/wheels" \
      --only-binary=:all: --no-cache-dir --progress-bar off \
      --extra-index-url "https://pypi.org/simple" \
      "${TARGET_PIP_ARGS[@]}" \
      || die "--sft 已指定但 SFT 依赖下载失败。不允许带病出厂：
     去掉 --sft 重跑，或修好网络后重跑。构建机 python3 = $(python3 -V 2>&1)"
fi

if [ "$DRY" -eq 0 ]; then
  NW="$(find "$BUNDLE/wheels" -name '*.whl' | wc -l | tr -d ' ')"
  NS="$(find "$BUNDLE/wheels" -name '*.tar.gz' 2>/dev/null | wc -l | tr -d ' ')"
  ok "轮子 $NW 个（源码包 $NS 个）"
  [ "$NW" -gt 0 ] || die "一个轮子都没下到，检查网络/索引"
  if [ "$NS" -gt 0 ]; then
    warn "有源码包！跨平台模式下它们无法在目标机编译，请核对"
  fi
fi

# 自检：这些轮子的标签能不能被目标平台接受（在打包机上就拦住，别等到了内网才炸）
if [ "$DRY" -eq 0 ]; then
  if [ "$SKIP_CHECK" -eq 1 ]; then
    warn "已跳过依赖自检（--skip-check）"
  elif [ -f "$SCRIPT_DIR/15_diagnose.sh" ]; then
    log "  → 自检：轮子标签 vs 目标平台"
    if bash "$SCRIPT_DIR/15_diagnose.sh" --bundle "$BUNDLE" --req "$REQ_USE" --python python3 \
         --target-py "$PYVER" --target-abi "$ABI" --target-arch "$ARCH" --target-glibc "$GLIBC" \
         > "$WORK/diag.log" 2>&1; then
      ok "依赖自检通过（所有轮子都能被目标平台接受）"
      grep -E "python 标签|abi    标签|平台   标签" "$WORK/diag.log" | sed 's/^ */      /' || true
    else
      tail -28 "$WORK/diag.log" | sed 's/^/      /'
      die "依赖自检失败：这份包装不到目标机上。按上面提示修参数后重跑（或 --skip-check 强打）"
    fi
    if [ "$WITH_SFT" -eq 1 ]; then
      log "  → 自检（SFT 依赖）：同一套判定"
      if bash "$SCRIPT_DIR/15_diagnose.sh" --bundle "$BUNDLE" --req "$SCRIPT_DIR/requirements-sft.txt" \
           --python python3 --target-py "$PYVER" --target-abi "$ABI" --target-arch "$ARCH" \
           --target-glibc "$GLIBC" > "$WORK/diag_sft.log" 2>&1; then
        ok "SFT 依赖自检通过"
      else
        tail -30 "$WORK/diag_sft.log" | sed 's/^/      /'
        die "SFT 依赖自检失败（很可能与 core 的轮子混装）"
      fi
    fi
  fi
fi

# ----------------------------------------------------------------- 附带 Python（可选）
step 4/7 "附带独立 Python（可选）"

if [ "$WITH_PYTHON" -eq 1 ]; then
  if [ "$DRY" -eq 1 ]; then
    log "  [dry-run] 下载 python-build-standalone cpython-$PYVER ($ARCH)"
  else
    URL="$(curl -fsSL "https://api.github.com/repos/astral-sh/python-build-standalone/releases/latest" 2>/dev/null \
      | python3 -c 'import json,sys
d=json.load(sys.stdin); pre=sys.argv[1]; suf=sys.argv[2]
print(next((a["browser_download_url"] for a in d.get("assets",[]) if a["name"].startswith(pre) and a["name"].endswith(suf)),""))' \
        "cpython-${PYVER}." "-${ARCH}-unknown-linux-gnu-install_only.tar.gz" || true)"
    if [ -n "${URL:-}" ]; then
      log "  → $URL"
      curl -fL --progress-bar -o "$WORK/py.tar.gz" "$URL" || die "Python 下载失败"
      mkdir -p "$BUNDLE/python"
      tar -xzf "$WORK/py.tar.gz" -C "$BUNDLE/python" --strip-components=1
      ok "$("$BUNDLE/python/bin/python3" -V 2>&1) 已打入离线包"
    else
      warn "没解析到 python-build-standalone 资产，跳过。"
      warn "  需要时手动下载 install_only 包，解压到离线包的 python/ 目录"
    fi
  fi
else
  ok "跳过（目标机需自带 Python ${PYVER}）"
fi

# ----------------------------------------------------------------- 拷代码
step 5/7 "拷贝代码"

if [ "$DRY" -eq 0 ]; then
  cp -R "$SRC" "$BUNDLE/src/$(basename "$SRC")"
  rm -rf "$BUNDLE/src/$(basename "$SRC")"/runs \
         "$BUNDLE/src/$(basename "$SRC")"/__pycache__ \
         "$BUNDLE/src/$(basename "$SRC")"/*.pyc 2>/dev/null || true
  find "$BUNDLE/src" -name '__pycache__' -type d -exec rm -rf {} + 2>/dev/null || true
  ok "代码已拷入 src/$(basename "$SRC")"

  cp "$SCRIPT_DIR/15_diagnose.sh"   "$BUNDLE/"
  cp "$SCRIPT_DIR/20_install.sh"    "$BUNDLE/"
  cp "$SCRIPT_DIR/30_run_t0.sh"     "$BUNDLE/"
  cp "$SCRIPT_DIR/40_run_t1.sh"     "$BUNDLE/"
  cp "$REQ"                         "$BUNDLE/$(basename "$REQ")"
  if [ -f "$SCRIPT_DIR/requirements-sft.txt" ]; then
    cp "$SCRIPT_DIR/requirements-sft.txt" "$BUNDLE/"
  fi
  ok "安装/运行脚本已拷入"
fi

# ----------------------------------------------------------------- 元信息 + 校验和
step 6/7 "生成元信息与校验和"

if [ "$DRY" -eq 0 ]; then
  cat > "$BUNDLE/TARGET.txt" <<EOF
# 由 10_build_bundle.sh 写入。20_install.sh 会拿它和实际机器比对，不一致直接报错。
PYVER=$PYVER
ABI=$ABI
ARCH=$ARCH
GLIBC=$GLIBC
TORCH=$TORCH
EOF

  # P1-2：包必须能自证是哪个版本的脚本打的
  SELF_SHA="$( (command -v sha256sum >/dev/null 2>&1 && sha256sum "$SCRIPT_DIR/10_build_bundle.sh") \
             || shasum -a 256 "$SCRIPT_DIR/10_build_bundle.sh" | awk '{print $1"  "$2}' )"
  cat > "$BUNDLE/BUNDLE_INFO.txt" <<EOF
构建时间      : $(date '+%Y-%m-%d %H:%M:%S')
构建主机      : $(uname -s)/$(uname -m)
主机 Python   : $(python3 -V 2>&1)
脚本版本      : bringup-bundle r6
脚本指纹      : ${SELF_SHA}
目标架构      : $ARCH
目标 Python   : $PYVER ($ABI)
目标 glibc    : $GLIBC
torch 变体    : $TORCH  ($([ -n "$TORCH_INDEX" ] && echo "$TORCH_INDEX" || echo "未包含"))
打包模式      : $MODE
含 SFT 依赖   : $WITH_SFT
含独立 Python : $WITH_PYTHON
轮子数量      : $(find "$BUNDLE/wheels" -name '*.whl' | wc -l | tr -d ' ')
代码目录      : src/$(basename "$SRC")

关键轮子（如有多个版本/ABI 会全部列出）:
$(ls "$BUNDLE/wheels" 2>/dev/null | grep -iE '^(numpy|tokenizers|pyyaml|torch)-' | sed 's/^/  /')
EOF

  # 生成 sha256 清单（兼容 sha256sum -c 与 shasum -c）
  SHA="sha256sum"
  command -v sha256sum >/dev/null 2>&1 || SHA="shasum -a 256"
  ( cd "$BUNDLE" && find . -type f ! -name 'MANIFEST.sha256' -print \
      | sort | while IFS= read -r f; do
          h=$($SHA "$f" | awk '{print $1}')
          printf '%s  %s\n' "$h" "${f#./}"
        done ) > "$BUNDLE/MANIFEST.sha256"
  ok "MANIFEST.sha256: $(wc -l < "$BUNDLE/MANIFEST.sha256" | tr -d ' ') 个文件"
fi

# ----------------------------------------------------------------- 打包
step 7/7 "打 tar.gz"

mkdir -p "$OUTDIR"
OUTDIR="$(cd "$OUTDIR" && pwd)"

if [ "$DRY" -eq 1 ]; then
  log "  [dry-run] tar -czf $OUTDIR/$NAME.tar.gz -C $WORK $NAME"
  log ""
  log "  dry-run 结束，未真正下载。去掉 --dry-run 执行。"
  exit 0
fi

tar -czf "$OUTDIR/$NAME.tar.gz" -C "$WORK" "$NAME"

SHA="sha256sum"
command -v sha256sum >/dev/null 2>&1 || SHA="shasum -a 256"
( cd "$OUTDIR" && $SHA "$NAME.tar.gz" > "$NAME.tar.gz.sha256" )

SIZE="$(du -h "$OUTDIR/$NAME.tar.gz" | awk '{print $1}')"
SUM="$(awk '{print $1}' "$OUTDIR/$NAME.tar.gz.sha256")"

log ""
log "======================================================================"
log " 打包完成"
log "======================================================================"
log "  文件   : $OUTDIR/$NAME.tar.gz"
log "  大小   : $SIZE"
log "  SHA256 : $SUM"
log ""
log "  目标平台（务必与服务器 python3 -VV 一致，否则包白传）："
log "    Python $PYVER   abi $ABI   架构 $ARCH   glibc $GLIBC   torch $TORCH"
log ""
log "  下一步（在【有网机器】执行，把包传到内网）："
log "    scp $OUTDIR/$NAME.tar.gz 用户@跳板机:/tmp/"
log "    # 或用 U 盘；记得 .sha256 也一起带上"
log ""
log "  到了内网服务器后："
log "    sha256sum -c $NAME.tar.gz.sha256     # 先校验完整性"
log "    tar -xzf $NAME.tar.gz"
log "    cd $NAME && bash 20_install.sh"
log "======================================================================"
