# 5090 · 0.5B LLM 跑通流程 —— 交付包

打包于 2026-10-27。**目标：在内网服务器上把 LLM 训练管线端到端跑通**（不追求模型质量）。

---

## 包里有什么

```
5090-llm-bringup-20261027/
├── QUICKSTART.md                       ← 你正在看的
├── PACKAGE_INFO.txt                    包内容清单
├── MANIFEST.sha256                     逐文件校验和
│
├── offline-deploy/                     ★ 内网离线部署（5 个脚本）
│   ├── README.md                       操作手册（含报错速查表）
│   ├── 00_preflight.sh                 内网服务器：探环境
│   ├── 10_build_bundle.sh              有网机器：下轮子 + 打包
│   ├── 20_install.sh                   内网服务器：离线安装
│   ├── 30_run_t0.sh                    内网服务器：7 秒冒烟
│   ├── 40_run_t1.sh                    内网 GPU：0.5B 正式档
│   └── requirements-{core,sft}.txt
│
├── 5090-0.5b-kit/                      ★ 训练代码
│   ├── README.md
│   ├── bringup.py                      一条命令跑通 6 个阶段
│   ├── profiler.py                     性能画像（时间分解/MFU/算子热点）
│   ├── pretrain.py                     LlamaMini 模型 + 训练循环
│   ├── build_tokenizer.py, pack_corpus.py, env_check.py
│   └── configs/                        toy / 0.5b / dapt / sft / dpo
│
├── 5090-0.5B-跑通流程-施工计划.md        ★ 当前阶段的方案
└── RTX5090-0.5B-LLM训练全流程.md         质量阶段的参考方案
```

**不含**：torch / 依赖轮子（3–5 GB）。原因见下文"为什么没有轮子"。

---

## 30 秒确认这个包是好的

**如果手边机器有 Python + torch**：

```bash
cd 5090-0.5b-kit
python bringup.py --tier toy --device cpu
```

约 7 秒，看到 `结论: PASS ✓` 就说明代码完好、管线通。

**如果没有 torch**（大多数情况）：

```bash
cd offline-deploy
bash 00_preflight.sh
```

它会打印环境探测结果并生成 `target-info.txt`。在 Mac 上跑会有 `[FAIL] 目标必须是 Linux`，这是**预期行为**——预检是给内网 Linux 服务器用的。

---

## 三条使用路径

### 路径 A：内网服务器已经装好 Python + torch

直接验证：

```bash
cd 5090-0.5b-kit
python bringup.py --tier toy --device cpu      # 7 秒
python bringup.py --tier full --device cuda    # 1.5–2 小时
```

### 路径 B：内网服务器什么都没有（最常见）★

四步走，详见 `offline-deploy/README.md`：

```bash
# ① 内网服务器：探环境
bash offline-deploy/00_preflight.sh && cat offline-deploy/target-info.txt

# ② 有网机器：把 target-info.txt 带过去，打包
bash offline-deploy/10_build_bundle.sh --target-info target-info.txt

# ③ 把 dist/offline-bundle-*.tar.gz 传回内网，解压后
tar -xzf offline-bundle-*.tar.gz && cd offline-bundle-* && bash 20_install.sh

# ④ 跑通
bash 30_run_t0.sh     # 7 秒 PASS
bash 40_run_t1.sh     # 2 小时，出性能画像
```

### 路径 C：先在能上网的机器上试

```bash
cd 5090-0.5b-kit
pip install torch --index-url https://download.pytorch.org/whl/cu130
pip install -r requirements.txt
python bringup.py --tier toy --device cpu
```

---

## 为什么没有轮子（torch 等）

轮子是**针对目标机的 Python 版本、glibc、CPU 架构**编译的，猜错了装不上（`is not a supported wheel on this platform`）。
所以必须先在目标机跑 `00_preflight.sh`，拿到 `PYTHON_VER / PYTHON_TAG / GLIBC / ARCH`，再由 `10_build_bundle.sh` 精确下载。

这也让包从 5 GB 降到 100 KB，方便你用 U 盘/聊天工具随便传。

> 拿到预检结果后，打包就一条命令，全自动。
> 目标机确定是 **x86_64 + Python 3.12 + glibc ≥ 2.28** 的话，也可以跳过预检直接：
> `bash offline-deploy/10_build_bundle.sh`（默认值就是这套）。

---

## 校验这个包

```bash
sha256sum -c 5090-llm-bringup-20261027.tar.gz.sha256   # 外层 tar
cd 5090-llm-bringup-20261027
sha256sum -c MANIFEST.sha256                            # 包内每个文件
```

---

## 四个数字先记住

| | |
|---|---|
| T0 冒烟 | **7 秒**，5.48M 参数，6 个阶段全绿 |
| T1 正式 | **1.5–2 小时**，494.3M 参数，100M tokens |
| 离线包大小 | 3–5 GB（cu128）；纯 CPU 版约 300 MB |
| 磁盘需求 | 安装峰值约 12 GB |

遇到报错先翻 `offline-deploy/README.md` 的 **§6.2 报错速查表**（12 条常见现象）。
